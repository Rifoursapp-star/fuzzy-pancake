# Refours Cam: build guide

A camera you build yourself that works with SafeEye. It streams video, hears sound, has a siren, a motion sensor and an **SOS button** you hold for 2 seconds. SafeEye finds it on your Wi-Fi by itself.

> **Status:** the camera software is written and tested on a computer (control API, pairing, SOS button events, siren timer, discovery, video commands). It has **not been run on a real Raspberry Pi with a real camera yet**. Expect to adjust things during your first build, and test every safety feature (siren, SOS) before you rely on it. Part names are what I believe is current: check availability and prices before you buy.

## 1. Choose your version

| | **Refours Cam Home** | **Refours Cam Zoom** |
|---|---|---|
| For | Doors, gates, yards, rooms up to about 50 m | Long range, compounds, roads, farms |
| Computer | Raspberry Pi Zero 2 W | Raspberry Pi 4 or 5 |
| Camera | Raspberry Pi Camera Module 3 (autofocus; the wide version for rooms) | Raspberry Pi HQ Camera + a C/CS-mount lens |
| Lens | built in | 16 mm (medium) up to 50-100 mm telephoto |
| Power | 5 V power supply (2.5 A) | Official power supply, or PoE with a PoE HAT (one cable for power and video) |
| Extras (both) | PIR motion sensor (HC-SR501), SOS push button, status LED + 330 ohm resistor, buzzer or siren, USB microphone | same, plus IR illuminators for night |

Also needed: microSD card (16 GB or more), a weatherproof box for outdoors, a camera mount, jumper wires.

## 2. How far can it really see?

Distance is decided by the lens and the sensor, not the software. For SafeEye to tell that something is a **person**, that person should be at least about **40 pixels tall** in the video (YOLO needs roughly this; the built-in OpenCV detector needs about 100+). The table shows a 1.7 m person with the HQ Camera at 1080p video (calculated, not measured):

| Lens | Sideways view | 100 m | 250 m | 500 m | 1000 m |
|---|---|---|---|---|---|
| 6 mm | 55 degrees | 23 px | 9 px | 5 px | 2 px |
| 16 mm | 22 degrees | 62 px | 25 px | 12 px | 6 px |
| 50 mm | 7 degrees | 195 px | 78 px | 39 px | 19 px |
| 100 mm | 3.6 degrees | 390 px | 156 px | 78 px | 39 px |

What this means:
- **100 m:** a 16 mm lens is enough. **250-500 m:** you need 50 mm or more.
- **1 km is possible only with about a 100 mm lens**, and then the camera sees just 63 m of width at that distance. It must be mounted rock-solid (wind shake ruins it), and haze, heat shimmer and darkness will limit it often. For wide coverage at 1 km you need several cameras or a motorised pan/tilt mount (not included yet).
- **Night:** ordinary cameras need light. Use the NoIR version of the camera with infrared illuminators, but IR light reaches only tens of metres. Seeing people far away in the dark needs a **thermal camera**, which is a different, much more expensive product. It can still connect to SafeEye if it offers an RTSP stream.
- **"Motion sensors that detect over a kilometre"** do not exist in cheap hardware. The PIR sensor in this build detects people about 5-7 m away. For long range, SafeEye uses video, and radar would need a separate commercial unit.

## 3. Wiring (Raspberry Pi pin numbers are BCM / GPIO numbers)

| Part | Connect to | Notes |
|---|---|---|
| Camera | The camera connector on the Pi, with the right ribbon cable | Pi Zero 2 W uses a smaller cable than Pi 4/5. Power off first. |
| SOS button | GPIO 27 and GND | No resistor needed (the Pi pulls the pin up). Hold 2 seconds to send. |
| PIR sensor | VCC to 5 V, GND to GND, OUT to GPIO 17 | The OUT pin is 3.3 V, which is safe for the Pi. |
| Status LED | GPIO 24 > 330 ohm resistor > LED long leg; LED short leg to GND | Steady = running. Blinks when SOS is sent. |
| Siren / buzzer | GPIO 22 | **Small active buzzer only** (up to about 10 mA). For a real siren or relay, GPIO 22 drives a transistor (e.g. 2N2222 with 1 k ohm resistor) or a relay module, and the siren gets its own power supply. **Never connect a siren or relay straight to a Pi pin.** Add a diode across a relay coil. |
| Microphone | USB port | A USB microphone is the easy choice. Find its name with `arecord -l`, then set `audio: true` and `audio_device` (for example `plughw:1,0`) in the camera config. |

Change the pin numbers in `/var/lib/refourscam/config.json` if you wire differently. Set a pin to `null` to leave a part out.

## 4. Set it up

1. On another computer, use **Raspberry Pi Imager** to write **Raspberry Pi OS Lite (64-bit)** to the microSD card. In its settings, set your Wi-Fi, a username and password, and turn on SSH.
2. Put the card in the Pi, connect the camera, and power it on. Log in with SSH.
3. Test the camera: `rpicam-hello --list-cameras` should list it.
4. Copy the `refourscam` folder from this project to the Pi (for example with `scp -r refourscam pi@<address>:~`).
5. On the Pi: `cd refourscam && sudo ./install.sh`. It installs the software and the video server, starts them, and **prints the pairing code**.
6. Write the pairing code down. Anyone with it can watch the camera. To see it again: `sudo -u refourscam env REFOURSCAM_HOME=/var/lib/refourscam PYTHONPATH=/opt/refourscam python3 -m refourscam show-pairing`.

## 5. Connect it to SafeEye

- **Android:** IP cameras > **Find Refours Cams on this Wi-Fi** > pick it > enter the pairing code.
- **Desktop:** `run discover`, then `run pair <address> --code <pairing code> --siren-on-alert`.
- Test the video in any player: `rtsp://refours:<pairing code>@<address>:8554/stream`.

Then SafeEye watches the video, saves alerts with clips, and (desktop) **listens for the SOS button**: hold it for 2 seconds and the camera's siren sounds for 10 seconds while SafeEye sends the SOS to your contacts. With `--siren-on-alert`, the camera's siren also sounds when SafeEye sees movement.

## 6. Security: please read

- **Keep the pairing code private.** It is the video password and the control password.
- **Never forward the camera's ports to the internet.** The control API is plain HTTP, made for your home network. To reach the camera from outside, use a VPN such as WireGuard or Tailscale.
- Wrong codes are limited: 5 wrong tries block that address for a minute. The siren can never be left on longer than 2 minutes.
- The camera announces only its name and ports on the network, never the code.
- Update the Pi regularly: `sudo apt update && sudo apt full-upgrade`.

## 7. Safety and law
- Mains power and PoE can hurt you. Use certified power supplies, keep mains wiring away from the electronics, and use a proper outdoor-rated box with sealed cable glands.
- Do not point cameras into neighbours' windows or private spaces. Recording and audio laws differ by country: get consent and put up notices where required.
- A siren that is too loud can hurt hearing and can break local noise laws. Test it at low volume first.

## 8. Optional: a pan/tilt mount that follows movement

This is what makes one long-range camera cover a wide area: with a 100 mm lens you see only 63 m of width at 1 km, so the camera turns toward whatever moves.

**Parts:** two NEMA 17 stepper motors with gearing (a 5:1 planetary gearbox or a worm gear: the gearing gives smooth, strong, precise turning), two stepper driver boards (A4988 or TMC2209), a **separate** 12 V power supply for the motors, a 100 uF capacitor across the motor supply, and a sturdy mount. A telephoto lens is heavy and long: balance it, and expect to design or buy a proper pan/tilt head.

| Driver / pin | Raspberry Pi GPIO |
|---|---|
| Pan STEP / DIR | 5 / 6 |
| Tilt STEP / DIR | 13 / 19 |
| ENABLE (both drivers, tied together) | 26 |
| Grounds | Pi GND, driver GND and motor supply GND all joined |

Set each driver's current limit to suit your motor **before** connecting it (the small screw on the A4988). Never connect or disconnect a motor while the driver is powered.

**Turn it on** in `/var/lib/refourscam/config.json`:
- `"ptz_enabled": true`
- `steps_per_degree_pan` / `_tilt` = motor steps per turn x microsteps x gear ratio / 360. Example: 200 x 16 x 5 / 360 = 44.4 (the default).
- **`hfov_deg` = your lens's sideways field of view** (6 mm = 55.3, 16 mm = 22.2, 50 mm = 7.2, 100 mm = 3.6). Tracking aims by this number, so a wrong value means a badly aimed camera.
- Soft limits `pan_min/pan_max/tilt_min/tilt_max` so the mount cannot twist cables or hit its stops.

**Centre the mount by hand before you power it on.** There are no limit switches: the software assumes it starts at the centre, and the soft limits are measured from there.

**Check directions:** `python3 -m refourscam ptz-test` moves right, left, up, down by 10 degrees. If a direction is wrong, set `pan_invert` or `tilt_invert` to true.

**Use it from SafeEye (desktop):**
- `run pair <address> --code <code> --auto-track` turns tracking on (it learns the camera's field of view).
- `run ptz Gate --pan 15 --tilt 5`, `run ptz Gate --home`, `run ptz Gate --patrol on` aim it by hand or sweep between patrol points.

**How tracking behaves:** it works in small steps. SafeEye finds where the movement is, turns up to 6 degrees toward it, waits until the mount has stopped, then looks again. It ignores the picture while the camera turns (a turning camera makes the whole scene look like movement). It follows the centre of all moving things, not one particular person, and it handles a walking person, not a fast car. After 60 seconds without movement it returns to the home view. In tests the tracker turns to a target 20 degrees away in a few clean steps without overshooting, but real motors, backlash and wind are not tested yet.

**Safety:** a stepper mount can pinch fingers and cables. Keep hands clear when it is powered, set sensible soft limits, and never rely on it to hold a heavy lens over people.

## 9. Not done yet
- A zoom/focus lens controller, and limit switches so the mount can find its own centre
- Battery and solar power version
- 3D-printable case and mount files
- Over-the-air updates
- Android listening for the SOS button, and Android auto-tracking (desktop only for now)
- An encrypted (HTTPS) control connection
- Following one chosen person: tracking follows the centre of movement

## 10. Files
- `refourscam/` - the camera software (Python): control API, SOS button, motion sensor, siren, pan/tilt mount, announcement, video pipeline
- `systemd/` - start-on-boot services
- `install.sh` - one-command installer for the Pi
- `tests/` - automated tests (`python -m pytest refourscam/tests`)
- Try it without any hardware: `PYTHONPATH=refourscam REFOURSCAM_HOME=/tmp/cam python3 -m refourscam run --simulate`
