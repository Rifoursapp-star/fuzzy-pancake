"""Camera settings. Generated on first start and saved as JSON."""

from __future__ import annotations

import json
import os
import secrets
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

# No 0/O/1/I/L so the pairing code is easy to read off a label.
_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def home_dir() -> Path:
    path = Path(os.environ.get("REFOURSCAM_HOME") or "/var/lib/refourscam")
    path.mkdir(parents=True, exist_ok=True)
    return path


@dataclass
class CamConfig:
    name: str = "Refours Cam"
    device_id: str = ""
    # One secret for pairing: it is the video password AND the control-API token.
    pairing_code: str = ""
    api_port: int = 8080
    rtsp_port: int = 8554
    rtsp_path: str = "stream"
    width: int = 1920
    height: int = 1080
    fps: int = 15
    bitrate_kbps: int = 4000
    hflip: bool = False
    vflip: bool = False
    audio: bool = False                 # add the microphone to the video stream
    audio_device: str = "plughw:1,0"    # ALSA name of the USB/I2S microphone
    # Raspberry Pi GPIO numbers (BCM). Use null to leave a part out.
    pir_pin: int | None = 17            # motion sensor
    button_pin: int | None = 27         # SOS / panic button (hold 2 seconds)
    siren_pin: int | None = 22          # buzzer or relay
    led_pin: int | None = 24            # status LED
    siren_max_seconds: int = 120        # the siren can never be left on longer than this
    # Lens field of view, sideways, in degrees. SET THIS TO MATCH YOUR LENS (HQ Camera:
    # 6 mm = 55.3, 16 mm = 22.2, 50 mm = 7.2, 100 mm = 3.6). Auto-tracking depends on it.
    hfov_deg: float = 55.0
    # Pan/tilt mount (two stepper motors with step/direction drivers such as A4988 or TMC2209).
    ptz_enabled: bool = False
    pan_step_pin: int | None = 5
    pan_dir_pin: int | None = 6
    tilt_step_pin: int | None = 13
    tilt_dir_pin: int | None = 19
    ptz_enable_pin: int | None = 26     # driver ENABLE (active low); null if not wired
    steps_per_degree_pan: float = 44.4  # motor steps x microsteps x gear ratio / 360
    steps_per_degree_tilt: float = 44.4
    ptz_speed_dps: float = 20.0         # degrees per second
    pan_min: float = -90.0              # + is to the right
    pan_max: float = 90.0
    tilt_min: float = -30.0             # + is up
    tilt_max: float = 45.0
    pan_invert: bool = False            # flip if the motor turns the wrong way
    tilt_invert: bool = False
    patrol_points: list = None          # [[pan, tilt], ...]; default sweeps left, centre, right
    patrol_dwell_s: float = 8.0         # how long to look at each patrol point


def path_for(home: Path | None = None) -> Path:
    return (home or home_dir()) / "config.json"


def load_or_create(home: Path | None = None) -> CamConfig:
    path = path_for(home)
    cfg = CamConfig()
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        known = set(CamConfig.__dataclass_fields__)
        cfg = CamConfig(**{k: v for k, v in data.items() if k in known})
    changed = False
    if not cfg.device_id:
        cfg.device_id, changed = uuid.uuid4().hex[:8], True
    if not cfg.pairing_code:
        cfg.pairing_code, changed = "".join(secrets.choice(_ALPHABET) for _ in range(10)), True
    if changed or not path.exists():
        save(cfg, home)
    return cfg


def save(cfg: CamConfig, home: Path | None = None) -> None:
    path = path_for(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(cfg), indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)  # holds the pairing code
    except OSError:
        pass
