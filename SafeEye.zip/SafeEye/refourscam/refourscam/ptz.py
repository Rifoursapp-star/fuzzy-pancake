"""Pan/tilt mount control: two stepper motors, soft limits, patrol.

There are no limit switches, so the mount ASSUMES it is centred (0, 0) when the software starts.
Centre it by hand before powering on, or the soft limits will be off by the same amount."""

from __future__ import annotations

import math
import threading
import time

from .config import CamConfig


class FakeDriver:
    """Counts step pulses instead of moving motors. For tests and --simulate."""

    def __init__(self) -> None:
        self.pulses = {"pan": 0, "tilt": 0}
        self.enabled = False

    def enable(self, on: bool) -> None:
        self.enabled = on

    def pulse(self, axis: str, direction: int) -> None:
        self.pulses[axis] += 1

    def close(self) -> None:
        pass


class GpioDriver:
    """Step/direction pins on the Raspberry Pi (gpiozero)."""

    def __init__(self, cfg: CamConfig) -> None:
        from gpiozero import DigitalOutputDevice

        def pin(n):
            return DigitalOutputDevice(n) if n is not None else None

        self._step = {"pan": pin(cfg.pan_step_pin), "tilt": pin(cfg.tilt_step_pin)}
        self._dir = {"pan": pin(cfg.pan_dir_pin), "tilt": pin(cfg.tilt_dir_pin)}
        self._enable = pin(cfg.ptz_enable_pin)
        self._invert = {"pan": cfg.pan_invert, "tilt": cfg.tilt_invert}

    def enable(self, on: bool) -> None:
        if self._enable:
            self._enable.value = not on  # drivers are enabled by a LOW pin

    def pulse(self, axis: str, direction: int) -> None:
        step, dirpin = self._step[axis], self._dir[axis]
        if step is None or dirpin is None:
            return
        dirpin.value = (direction > 0) != self._invert[axis]
        step.on()
        time.sleep(0.000005)
        step.off()

    def close(self) -> None:
        self.enable(False)
        for d in (*self._step.values(), *self._dir.values(), self._enable):
            if d:
                d.close()


class PanTilt:
    def __init__(self, cfg: CamConfig, driver) -> None:
        self.cfg, self.driver = cfg, driver
        self._spd = {"pan": cfg.steps_per_degree_pan, "tilt": cfg.steps_per_degree_tilt}
        self._pos = {"pan": 0, "tilt": 0}      # in steps
        self._target = {"pan": 0, "tilt": 0}
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._closed = threading.Event()
        self._patrol_on = threading.Event()
        self.points = [list(p) for p in (cfg.patrol_points or [[-30, 0], [0, 0], [30, 0]])]
        self._delay = 1.0 / max(1.0, cfg.ptz_speed_dps * max(self._spd.values()))
        driver.enable(True)
        threading.Thread(target=self._run, daemon=True, name="refourscam-ptz").start()
        threading.Thread(target=self._patrol_loop, daemon=True, name="refourscam-patrol").start()

    # -- public ------------------------------------------------------------

    def position(self) -> tuple[float, float]:
        with self._lock:
            return (round(self._pos["pan"] / self._spd["pan"], 2), round(self._pos["tilt"] / self._spd["tilt"], 2))

    @property
    def moving(self) -> bool:
        with self._lock:
            return self._pos != self._target

    @property
    def patrolling(self) -> bool:
        return self._patrol_on.is_set()

    def limits(self) -> dict:
        c = self.cfg
        return {"pan": [c.pan_min, c.pan_max], "tilt": [c.tilt_min, c.tilt_max]}

    def move_to(self, pan: float, tilt: float, manual: bool = True) -> tuple[float, float]:
        """Go to an angle (clamped to the limits). A manual command ends patrol."""
        if manual:
            self.set_patrol(False)
        c = self.cfg
        pan = min(max(_finite(pan), c.pan_min), c.pan_max)
        tilt = min(max(_finite(tilt), c.tilt_min), c.tilt_max)
        with self._lock:
            self._target = {"pan": round(pan * self._spd["pan"]), "tilt": round(tilt * self._spd["tilt"])}
        self._wake.set()
        return pan, tilt

    def move_by(self, dpan: float, dtilt: float) -> tuple[float, float]:
        """Turn by an amount, from where the mount is heading (so quick commands add up)."""
        with self._lock:
            pan = self._target["pan"] / self._spd["pan"]
            tilt = self._target["tilt"] / self._spd["tilt"]
        return self.move_to(pan + _finite(dpan), tilt + _finite(dtilt))

    def home(self) -> None:
        self.move_to(0, 0)

    def set_patrol(self, on: bool) -> None:
        if on:
            self._patrol_on.set()
        else:
            self._patrol_on.clear()

    def wait_until_still(self, timeout: float = 10.0) -> bool:
        end = time.monotonic() + timeout
        while self.moving:
            if time.monotonic() > end:
                return False
            time.sleep(0.005)
        return True

    def close(self) -> None:
        self._patrol_on.clear()
        self._closed.set()
        self._wake.set()
        self.driver.close()

    # -- motor thread --------------------------------------------------------

    def _run(self) -> None:
        while not self._closed.is_set():
            with self._lock:
                todo = {a: (self._target[a] > self._pos[a]) - (self._target[a] < self._pos[a]) for a in self._pos}
            if not any(todo.values()):
                self._wake.wait(0.5)
                self._wake.clear()
                continue
            for axis, direction in todo.items():
                if direction:
                    self.driver.pulse(axis, direction)
                    with self._lock:
                        self._pos[axis] += direction
            if self._delay > 0:
                time.sleep(self._delay)

    def _patrol_loop(self) -> None:
        while not self._closed.is_set():
            if not self._patrol_on.wait(0.2):
                continue
            for pan, tilt in self.points:
                if not self._patrol_on.is_set() or self._closed.is_set():
                    break
                self.move_to(pan, tilt, manual=False)
                while self.moving and self._patrol_on.is_set() and not self._closed.is_set():
                    time.sleep(0.02)
                end = time.monotonic() + self.cfg.patrol_dwell_s
                while time.monotonic() < end and self._patrol_on.is_set() and not self._closed.is_set():
                    time.sleep(0.02)


def _finite(value) -> float:
    value = float(value)
    if not math.isfinite(value) or abs(value) > 1000:
        raise ValueError("angle out of range")
    return value
