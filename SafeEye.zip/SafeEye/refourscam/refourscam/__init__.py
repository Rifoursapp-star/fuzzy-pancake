"""Refours Cam firmware: the software that runs inside the Refours Cam (Raspberry Pi)."""

__version__ = "1.0.0"
MODEL = "Refours Cam"
SERVICE_TYPE = "_refourscam._tcp.local."
