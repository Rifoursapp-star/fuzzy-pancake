"""Announces the camera on the local network (mDNS) so SafeEye can find it automatically.

The announcement holds only the name, id and ports. It never includes the pairing code."""

from __future__ import annotations

import socket
from typing import Callable

from . import SERVICE_TYPE
from .config import CamConfig


def local_ip() -> str:
    """The address other devices on the network use to reach this one."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no packet is sent
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def txt_records(cfg: CamConfig) -> dict[str, str]:
    return {
        "id": cfg.device_id, "name": cfg.name, "model": "Refours Cam",
        "api_port": str(cfg.api_port), "rtsp_port": str(cfg.rtsp_port), "path": cfg.rtsp_path,
    }


def advertise(cfg: CamConfig, address: str | None = None) -> Callable[[], None] | None:
    """Starts announcing. Returns a function that stops it, or None if zeroconf is missing."""
    try:
        from zeroconf import ServiceInfo, Zeroconf
    except ImportError:
        return None
    ip = address or local_ip()
    info = ServiceInfo(
        SERVICE_TYPE,
        f"Refours Cam {cfg.device_id}.{SERVICE_TYPE}",
        addresses=[socket.inet_aton(ip)],
        port=cfg.api_port,
        properties=txt_records(cfg),
        server=f"refourscam-{cfg.device_id}.local.",
    )
    zc = Zeroconf()
    zc.register_service(info)

    def stop() -> None:
        zc.unregister_service(info)
        zc.close()

    return stop
