"""Hardware layer: the Raspberry Pi pins (or a fake one for tests and --simulate)."""

from __future__ import annotations

import threading
from typing import Callable

from .config import CamConfig


class Hardware:
    """What the rest of the software needs from the camera's parts."""

    def __init__(self) -> None:
        self.on_button: Callable[[], None] = lambda: None   # SOS button held
        self.on_motion: Callable[[], None] = lambda: None   # PIR sensor fired

    def siren(self, on: bool) -> None: ...
    def led(self, on: bool) -> None: ...
    def close(self) -> None: ...


class FakeHardware(Hardware):
    """No real pins. Lets you press the button in code. Used by tests and --simulate."""

    def __init__(self) -> None:
        super().__init__()
        self.siren_on = False
        self.led_on = False
        self.siren_history: list[bool] = []

    def siren(self, on: bool) -> None:
        self.siren_on = on
        self.siren_history.append(on)

    def led(self, on: bool) -> None:
        self.led_on = on

    def press_button(self) -> None:
        self.on_button()

    def trigger_motion(self) -> None:
        self.on_motion()


class GpioHardware(Hardware):
    """Real Raspberry Pi pins through gpiozero."""

    def __init__(self, cfg: CamConfig) -> None:
        super().__init__()
        from gpiozero import LED, Button, Buzzer, MotionSensor  # only exists on the Pi

        self._parts = []
        self._siren = Buzzer(cfg.siren_pin) if cfg.siren_pin is not None else None
        self._led = LED(cfg.led_pin) if cfg.led_pin is not None else None
        if cfg.button_pin is not None:
            # Hold for 2 seconds so a bump in a bag does not send an SOS.
            button = Button(cfg.button_pin, pull_up=True, hold_time=2)
            button.when_held = lambda: self.on_button()
            self._parts.append(button)
        if cfg.pir_pin is not None:
            pir = MotionSensor(cfg.pir_pin)
            pir.when_motion = lambda: self.on_motion()
            self._parts.append(pir)

    def siren(self, on: bool) -> None:
        if self._siren:
            self._siren.on() if on else self._siren.off()

    def led(self, on: bool) -> None:
        if self._led:
            self._led.on() if on else self._led.off()

    def close(self) -> None:
        for part in [*self._parts, self._siren, self._led]:
            if part:
                part.close()


class SirenController:
    """Turns the siren on for a limited time. It can never be left on forever."""

    def __init__(self, hw: Hardware, max_seconds: int, on_change: Callable[[bool, str], None] | None = None):
        self._hw = hw
        self._max = max(1, max_seconds)
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()
        self._on_change = on_change or (lambda on, why: None)
        self.is_on = False

    def on(self, seconds: float, reason: str = "") -> float:
        seconds = min(max(1.0, float(seconds)), self._max)
        with self._lock:
            if self._timer:
                self._timer.cancel()
            self._hw.siren(True)
            self.is_on = True
            self._timer = threading.Timer(seconds, self._expire)
            self._timer.daemon = True
            self._timer.start()
        self._on_change(True, reason)
        return seconds

    def off(self, reason: str = "") -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None
            was_on, self.is_on = self.is_on, False
            self._hw.siren(False)
        if was_on:
            self._on_change(False, reason)

    def _expire(self) -> None:
        self.off("timer")
