"""Puts the camera together: video, control API, announcement, button, motion sensor, siren."""

from __future__ import annotations

import argparse
import signal
import sys
import threading
import time

from . import __version__, config as cfgmod
from .discovery import advertise, local_ip
from .events import EventLog
from .hal import FakeHardware, GpioHardware, Hardware, SirenController
from .ptz import FakeDriver, GpioDriver, PanTilt
from .server import CamServer
from .video import VideoStreamer, capture_pipeline, grab_snapshot, mediamtx_config

PIR_DEBOUNCE = 5.0     # seconds between motion-sensor events
SOS_SIREN_SECONDS = 10


class Camera:
    def __init__(self, cfg: cfgmod.CamConfig, hw: Hardware, snapshot_fn=None, video: VideoStreamer | None = None,
                 api_port: int | None = None, host: str = "0.0.0.0", ptz=None):
        self.cfg, self.hw, self.video, self.ptz = cfg, hw, video, ptz
        self.events = EventLog()
        self.siren = SirenController(hw, cfg.siren_max_seconds, self._siren_changed)
        self.server = CamServer(cfg, self.events, self.siren, snapshot_fn,
                                (lambda: video.running) if video else None, host=host, port=api_port, ptz=ptz)
        self._last_pir = 0.0
        hw.on_button = self._button
        hw.on_motion = self._motion

    def _button(self) -> None:
        self.events.add("sos_button", "SOS button held")
        self.siren.on(SOS_SIREN_SECONDS, "sos button")
        self._blink()

    def _motion(self) -> None:
        now = time.monotonic()
        if now - self._last_pir >= PIR_DEBOUNCE:
            self._last_pir = now
            self.events.add("pir", "motion sensor")

    def _siren_changed(self, on: bool, reason: str) -> None:
        self.events.add("siren_on" if on else "siren_off", reason)

    def _blink(self) -> None:
        def run():
            for _ in range(6):
                self.hw.led(True); time.sleep(0.15); self.hw.led(False); time.sleep(0.15)
        threading.Thread(target=run, daemon=True).start()

    def start(self) -> None:
        if self.video:
            self.video.start()
        self.server.start()
        self.hw.led(True)  # steady light = running

    def stop(self) -> None:
        self.siren.off("shutdown")
        if self.ptz:
            self.ptz.close()
        self.server.stop()
        if self.video:
            self.video.stop()
        self.hw.led(False)
        self.hw.close()


def show_pairing(cfg: cfgmod.CamConfig) -> None:
    ip = local_ip()
    print(f"""
  {cfg.name}  (id {cfg.device_id})

  Pairing code : {cfg.pairing_code}
  Address      : {ip}

  In SafeEye (desktop):   run pair {ip} --code {cfg.pairing_code}
  In SafeEye (Android):   IP cameras > Find Refours Cams > enter the code
  Video address (RTSP)    rtsp://refours:{cfg.pairing_code}@{ip}:{cfg.rtsp_port}/{cfg.rtsp_path}
  Keep the code private. Anyone with it can watch this camera.
""")


def ptz_test(cfg: cfgmod.CamConfig) -> int:
    """Moves 10 degrees each way so you can check the directions. + pan is RIGHT, + tilt is UP."""
    if not cfg.ptz_enabled:
        print("Pan/tilt is off. Set \"ptz_enabled\": true in the camera config first.")
        return 1
    mount = PanTilt(cfg, GpioDriver(cfg))
    try:
        for name, pan, tilt in (("RIGHT", 10, 0), ("back to centre", 0, 0), ("LEFT", -10, 0),
                                ("back to centre", 0, 0), ("UP", 0, 10), ("back to centre", 0, 0),
                                ("DOWN", 0, -10), ("back to centre", 0, 0)):
            print(f"Moving {name}...")
            mount.move_to(pan, tilt)
            mount.wait_until_still(60)
            time.sleep(0.5)
        print("Done. If a direction was wrong, set pan_invert / tilt_invert in the config.")
    finally:
        mount.close()
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="refourscam", description="Refours Cam firmware")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="start the camera")
    run.add_argument("--simulate", action="store_true", help="no real parts: for trying SafeEye without hardware")
    run.add_argument("--no-video", action="store_true", help="control API only")
    sub.add_parser("ptz-test", help="move the pan/tilt mount a little each way to check directions")
    sub.add_parser("show-pairing", help="print the pairing code and addresses")
    sub.add_parser("write-mediamtx-config", help="print the MediaMTX config")
    args = p.parse_args(argv)

    cfg = cfgmod.load_or_create()
    if args.command == "show-pairing":
        show_pairing(cfg)
        return 0
    if args.command == "write-mediamtx-config":
        sys.stdout.write(mediamtx_config(cfg))
        return 0

    if args.command == "ptz-test":
        return ptz_test(cfg)

    hw: Hardware = FakeHardware() if args.simulate else GpioHardware(cfg)
    ptz = None
    if cfg.ptz_enabled:
        ptz = PanTilt(cfg, FakeDriver() if args.simulate else GpioDriver(cfg))
    video = None if (args.simulate or args.no_video) else VideoStreamer(capture_pipeline(cfg))
    snap = None if (args.simulate or args.no_video) else (lambda: grab_snapshot(cfg))
    cam = Camera(cfg, hw, snap, video, ptz=ptz)
    cam.start()
    stop_advertising = advertise(cfg)
    print(f"Refours Cam {__version__} running. API on port {cam.server.port}."
          + ("" if stop_advertising else " (network announcement off: pip install zeroconf)"))
    show_pairing(cfg)

    done = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: done.set())
    try:
        done.wait()
    except KeyboardInterrupt:
        pass
    finally:
        if stop_advertising:
            stop_advertising()
        cam.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
