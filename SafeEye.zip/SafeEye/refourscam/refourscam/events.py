"""A small in-memory event list that SafeEye can wait on ("long polling")."""

from __future__ import annotations

import threading
import time
from collections import deque


class EventLog:
    def __init__(self, keep: int = 200):
        self._events: deque[dict] = deque(maxlen=keep)
        self._next_id = 1
        self._cond = threading.Condition()

    @property
    def last_id(self) -> int:
        with self._cond:
            return self._next_id - 1

    def add(self, kind: str, detail: str = "") -> int:
        with self._cond:
            event = {"id": self._next_id, "time": time.time(), "kind": kind, "detail": detail}
            self._next_id += 1
            self._events.append(event)
            self._cond.notify_all()
            return event["id"]

    def since(self, after_id: int, wait: float = 0.0) -> list[dict]:
        """Events newer than after_id. If there are none, waits up to `wait` seconds for one."""
        deadline = time.monotonic() + max(0.0, wait)
        with self._cond:
            while True:
                found = [e for e in self._events if e["id"] > after_id]
                remaining = deadline - time.monotonic()
                if found or remaining <= 0:
                    return found
                self._cond.wait(remaining)
