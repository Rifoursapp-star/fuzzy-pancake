"""The camera's control API (HTTP, local network). SafeEye uses it to listen for the SOS
button, sound the siren and fetch snapshots. Video itself is served separately over RTSP."""

from __future__ import annotations

import hmac
import json
import math
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable
from urllib.parse import parse_qs, urlparse

from . import MODEL, __version__
from .config import CamConfig
from .events import EventLog
from .hal import SirenController

MAX_FAILS = 5          # wrong codes allowed from one address...
LOCKOUT_SECONDS = 60   # ...before it is blocked for this long
MAX_WAIT = 25.0        # longest a client may wait for events


def cpu_temperature() -> float | None:
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as fh:
            return round(int(fh.read().strip()) / 1000, 1)
    except (OSError, ValueError):
        return None


class CamServer:
    def __init__(
        self,
        cfg: CamConfig,
        events: EventLog,
        siren: SirenController,
        snapshot_fn: Callable[[], bytes] | None = None,
        video_running_fn: Callable[[], bool] | None = None,
        host: str = "0.0.0.0",
        port: int | None = None,
        ptz=None,
    ):
        self.cfg, self.events, self.siren = cfg, events, siren
        self.ptz = ptz
        self.snapshot_fn = snapshot_fn
        self.video_running_fn = video_running_fn or (lambda: False)
        self.started = time.time()
        self._fails: dict[str, tuple[int, float]] = {}
        self._lock = threading.Lock()
        app = self

        class Handler(BaseHTTPRequestHandler):
            server_version = f"RefoursCam/{__version__}"

            def log_message(self, *args):  # keep the console quiet
                pass

            def do_GET(self):
                app.handle(self, "GET")

            def do_POST(self):
                app.handle(self, "POST")

        self.httpd = ThreadingHTTPServer((host, cfg.api_port if port is None else port), Handler)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self.httpd.serve_forever, daemon=True, name="refourscam-api")
        self._thread.start()

    def stop(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()

    # -- request handling ----------------------------------------------------

    def handle(self, h: BaseHTTPRequestHandler, method: str) -> None:
        url = urlparse(h.path)
        query = parse_qs(url.query)
        try:
            if method == "GET" and url.path == "/api/info":  # public: lets SafeEye identify the camera
                return self._json(h, 200, {
                    "model": MODEL, "version": __version__, "id": self.cfg.device_id, "name": self.cfg.name,
                    "rtsp_port": self.cfg.rtsp_port, "rtsp_path": self.cfg.rtsp_path,
                    "api_port": self.port, "audio": self.cfg.audio,
                    "ptz": self.ptz is not None, "hfov_deg": self.cfg.hfov_deg, "vfov_deg": self._vfov(),
                })
            if not self._authorized(h):
                return
            if method == "GET" and url.path == "/api/status":
                return self._json(h, 200, {
                    "uptime_s": int(time.time() - self.started), "cpu_temp_c": cpu_temperature(),
                    "siren_on": self.siren.is_on, "video_running": bool(self.video_running_fn()),
                    "last_event_id": self.events.last_id,
                })
            if method == "GET" and url.path == "/api/events":
                after = int(query.get("since", ["0"])[0])
                wait = min(float(query.get("wait", ["0"])[0]), MAX_WAIT)
                return self._json(h, 200, {"events": self.events.since(after, wait), "last_id": self.events.last_id})
            if method == "POST" and url.path == "/api/siren":
                body = self._body(h)
                if body.get("on", True):
                    seconds = self.siren.on(float(body.get("seconds", 10)), "api")
                    return self._json(h, 200, {"siren_on": True, "seconds": seconds})
                self.siren.off("api")
                return self._json(h, 200, {"siren_on": False})
            if url.path == "/api/ptz":
                if self.ptz is None:
                    return self._json(h, 501, {"error": "this camera has no pan/tilt mount"})
                if method == "POST":
                    body = self._body(h)
                    if body.get("home"):
                        self.ptz.set_patrol(False)
                        self.ptz.home()
                    elif "patrol" in body:
                        self.ptz.set_patrol(bool(body["patrol"]))
                    elif "pan" in body or "tilt" in body:
                        cur = self.ptz.position()
                        self.ptz.move_to(body.get("pan", cur[0]), body.get("tilt", cur[1]))
                    elif "dpan" in body or "dtilt" in body:
                        self.ptz.move_by(body.get("dpan", 0), body.get("dtilt", 0))
                    else:
                        raise ValueError("nothing to do")
                pan, tilt = self.ptz.position()
                return self._json(h, 200, {"pan": pan, "tilt": tilt, "moving": self.ptz.moving,
                                           "patrol": self.ptz.patrolling, "limits": self.ptz.limits()})
            if method == "GET" and url.path == "/api/snapshot":
                if not self.snapshot_fn:
                    return self._json(h, 501, {"error": "snapshots are not available"})
                data = self.snapshot_fn()
                h.send_response(200)
                h.send_header("Content-Type", "image/jpeg")
                h.send_header("Content-Length", str(len(data)))
                h.end_headers()
                h.wfile.write(data)
                return
            self._json(h, 404, {"error": "not found"})
        except (ValueError, KeyError, json.JSONDecodeError):
            self._json(h, 400, {"error": "bad request"})
        except Exception as exc:  # never crash the camera because of one request
            self._json(h, 500, {"error": type(exc).__name__})

    def _vfov(self) -> float:
        """Up-down field of view, from the sideways one and the picture shape."""
        ratio = self.cfg.height / self.cfg.width
        return round(math.degrees(2 * math.atan(math.tan(math.radians(self.cfg.hfov_deg) / 2) * ratio)), 2)

    def _authorized(self, h: BaseHTTPRequestHandler) -> bool:
        ip = h.client_address[0]
        now = time.monotonic()
        with self._lock:
            fails, until = self._fails.get(ip, (0, 0.0))
            if until > now:
                self._json(h, 429, {"error": "too many wrong codes, try again later"})
                return False
        supplied = h.headers.get("Authorization", "")
        ok = supplied.startswith("Bearer ") and hmac.compare_digest(
            supplied[7:].strip().encode(), self.cfg.pairing_code.encode()
        )
        with self._lock:
            if ok:
                self._fails.pop(ip, None)
                return True
            fails += 1
            self._fails[ip] = (fails, now + LOCKOUT_SECONDS if fails >= MAX_FAILS else 0.0)
        self._json(h, 401, {"error": "wrong or missing pairing code"})
        return False

    @staticmethod
    def _body(h: BaseHTTPRequestHandler) -> dict:
        length = int(h.headers.get("Content-Length") or 0)
        if length > 1024:
            raise ValueError("body too large")
        return json.loads(h.rfile.read(length) or b"{}")

    @staticmethod
    def _json(h: BaseHTTPRequestHandler, code: int, payload: dict) -> None:
        data = json.dumps(payload).encode()
        h.send_response(code)
        h.send_header("Content-Type", "application/json")
        h.send_header("Content-Length", str(len(data)))
        h.end_headers()
        h.wfile.write(data)
