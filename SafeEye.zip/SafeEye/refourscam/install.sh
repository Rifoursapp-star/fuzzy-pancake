#!/usr/bin/env bash
# Refours Cam installer for Raspberry Pi OS (Bookworm or newer, 64-bit recommended).
# Run on the Pi:   sudo ./install.sh
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then echo "Run with sudo:  sudo ./install.sh"; exit 1; fi
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "==> Installing packages"
apt-get update
apt-get install -y ffmpeg python3-gpiozero python3-lgpio python3-zeroconf curl ca-certificates
# Camera tools are called rpicam-apps on current Raspberry Pi OS, libcamera-apps on older ones.
apt-get install -y rpicam-apps || apt-get install -y libcamera-apps
command -v rpicam-vid >/dev/null || { echo "rpicam-vid not found: this needs Raspberry Pi OS Bookworm or newer."; exit 1; }

echo "==> Installing MediaMTX (video server)"
case "$(uname -m)" in
  aarch64) ARCH=arm64v8 ;;
  armv7l)  ARCH=armv7 ;;
  armv6l)  ARCH=armv6 ;;
  x86_64)  ARCH=amd64 ;;
  *) echo "Unsupported CPU: $(uname -m)"; exit 1 ;;
esac
TAG="$(curl -sIL -o /dev/null -w '%{url_effective}' https://github.com/bluenviron/mediamtx/releases/latest | sed 's|.*/||')"
[ -n "$TAG" ] || { echo "Could not find the latest MediaMTX version (no internet?)"; exit 1; }
TMP="$(mktemp -d)"
curl -fsSL "https://github.com/bluenviron/mediamtx/releases/download/${TAG}/mediamtx_${TAG}_linux_${ARCH}.tar.gz" | tar -xz -C "$TMP" mediamtx
install -m 755 "$TMP/mediamtx" /usr/local/bin/mediamtx
rm -rf "$TMP"

echo "==> Installing Refours Cam software"
id refourscam >/dev/null 2>&1 || useradd --system --home /var/lib/refourscam --shell /usr/sbin/nologin refourscam
for g in video gpio audio; do getent group "$g" >/dev/null && usermod -aG "$g" refourscam; done
rm -rf /opt/refourscam && mkdir -p /opt/refourscam
cp -r "$HERE/refourscam" /opt/refourscam/
cp "$HERE"/systemd/*.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now mediamtx.service refourscam.service

sleep 3
echo
echo "==> Done. Your camera's pairing details:"
sudo -u refourscam env REFOURSCAM_HOME=/var/lib/refourscam PYTHONPATH=/opt/refourscam python3 -m refourscam show-pairing
echo "Check it is running:  systemctl status refourscam"
