"""Tests for the Refours Cam software and its SafeEye integration.
Run:  python -m pytest refourscam/tests -q"""

import json
import os
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "refourscam"))
sys.path.insert(0, str(ROOT / "desktop"))

from refourscam import config as camcfg  # noqa: E402
from refourscam.app import Camera  # noqa: E402
from refourscam.events import EventLog  # noqa: E402
from refourscam.hal import FakeHardware, SirenController  # noqa: E402
from refourscam.server import LOCKOUT_SECONDS, MAX_FAILS  # noqa: E402
from refourscam.video import (VideoStreamer, capture_pipeline, mediamtx_config,  # noqa: E402
                              snapshot_command)

from safeeye_desktop import config as secfg  # noqa: E402
from safeeye_desktop.__main__ import main as safeeye_main  # noqa: E402
from safeeye_desktop.alerts import NullAlarm  # noqa: E402
from safeeye_desktop.monitor import CameraWorker  # noqa: E402
from safeeye_desktop.refours import (RefoursClient, RefoursError, RefoursWatcher,  # noqa: E402
                                     parse_service)
from safeeye_desktop.store import AlertStore  # noqa: E402

JPEG = b"\xff\xd8\xff\xe0fake-jpeg\xff\xd9"


@pytest.fixture
def cam(tmp_path):
    cfg = camcfg.load_or_create(tmp_path)
    hw = FakeHardware()
    camera = Camera(cfg, hw, snapshot_fn=lambda: JPEG, api_port=0, host="127.0.0.1")
    camera.start()
    yield camera
    camera.stop()


def url(cam, path=""):
    return f"http://127.0.0.1:{cam.server.port}{path}"


def call(cam, path, code=None, method="GET", body=None, headers=None):
    req = urllib.request.Request(url(cam, path), method=method,
                                 data=json.dumps(body).encode() if body is not None else None)
    if code is not None:
        req.add_header("Authorization", f"Bearer {code}")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


# ---- configuration ------------------------------------------------------------

def test_config_generates_stable_id_and_readable_code(tmp_path):
    a = camcfg.load_or_create(tmp_path)
    assert len(a.device_id) == 8 and len(a.pairing_code) == 10
    assert not set(a.pairing_code) & set("0O1IL")  # no look-alike characters
    b = camcfg.load_or_create(tmp_path)
    assert (a.device_id, a.pairing_code) == (b.device_id, b.pairing_code)
    if os.name == "posix":
        assert (tmp_path / "config.json").stat().st_mode & 0o777 == 0o600


def test_two_cameras_get_different_codes(tmp_path):
    a = camcfg.load_or_create(tmp_path / "a")
    b = camcfg.load_or_create(tmp_path / "b")
    assert a.pairing_code != b.pairing_code and a.device_id != b.device_id


# ---- events and siren --------------------------------------------------------

def test_event_long_poll_wakes_up_when_event_arrives():
    log = EventLog()
    threading.Timer(0.2, lambda: log.add("sos_button")).start()
    t0 = time.monotonic()
    events = log.since(0, wait=5)
    assert [e["kind"] for e in events] == ["sos_button"] and time.monotonic() - t0 < 2


def test_event_wait_times_out_empty_and_old_events_skipped():
    log = EventLog()
    first = log.add("a")
    t0 = time.monotonic()
    assert log.since(first, wait=0.3) == [] and 0.25 < time.monotonic() - t0 < 1.5


def test_siren_is_capped_and_turns_itself_off():
    hw, changes = FakeHardware(), []
    siren = SirenController(hw, max_seconds=1, on_change=lambda on, why: changes.append(on))
    assert siren.on(9999, "test") == 1  # asked for far too long: capped
    assert hw.siren_on and siren.is_on
    time.sleep(1.4)
    assert not hw.siren_on and not siren.is_on and changes == [True, False]


def test_siren_off_cancels_timer():
    hw = FakeHardware()
    siren = SirenController(hw, 60)
    siren.on(30)
    siren.off()
    assert not hw.siren_on and not siren.is_on


# ---- the control API ----------------------------------------------------------

def test_info_is_public_but_status_needs_the_code(cam):
    status, body = call(cam, "/api/info")
    info = json.loads(body)
    assert status == 200 and info["model"] == "Refours Cam" and info["id"] == cam.cfg.device_id
    assert cam.cfg.pairing_code not in body.decode()  # the code must never be announced
    assert call(cam, "/api/status")[0] == 401
    assert call(cam, "/api/status", "WRONG")[0] == 401
    assert call(cam, "/api/status", cam.cfg.pairing_code)[0] == 200


def test_code_in_url_is_not_accepted(cam):
    assert call(cam, f"/api/status?token={cam.cfg.pairing_code}")[0] == 401


def test_lockout_after_too_many_wrong_codes(cam):
    for _ in range(MAX_FAILS):
        assert call(cam, "/api/status", "nope")[0] == 401
    status, _ = call(cam, "/api/status", cam.cfg.pairing_code)  # even the right code waits
    assert status == 429 and LOCKOUT_SECONDS >= 30


def test_siren_via_api_and_events(cam):
    code = cam.cfg.pairing_code
    status, body = call(cam, "/api/siren", code, "POST", {"on": True, "seconds": 5000})
    assert status == 200 and json.loads(body)["seconds"] == cam.cfg.siren_max_seconds
    assert cam.hw.siren_on
    call(cam, "/api/siren", code, "POST", {"on": False})
    assert not cam.hw.siren_on
    kinds = [e["kind"] for e in json.loads(call(cam, "/api/events?since=0", code)[1])["events"]]
    assert kinds == ["siren_on", "siren_off"]


def test_bad_requests_are_rejected_cleanly(cam):
    code = cam.cfg.pairing_code
    assert call(cam, "/api/siren", code, "POST", {"seconds": "abc"})[0] == 400
    assert call(cam, "/api/siren", code, "POST", {"pad": "x" * 5000})[0] == 400
    assert call(cam, "/api/events?since=abc", code)[0] == 400
    assert call(cam, "/api/nothing", code)[0] == 404
    assert call(cam, "/api/status", code)[0] == 200  # still alive afterwards


def test_snapshot(cam, tmp_path):
    status, body = call(cam, "/api/snapshot", cam.cfg.pairing_code)
    assert status == 200 and body == JPEG
    cam.server.snapshot_fn = None
    assert call(cam, "/api/snapshot", cam.cfg.pairing_code)[0] == 501


def test_failing_snapshot_does_not_crash_the_camera(cam):
    def boom():
        raise RuntimeError("camera busy")
    cam.server.snapshot_fn = boom
    assert call(cam, "/api/snapshot", cam.cfg.pairing_code)[0] == 500
    assert call(cam, "/api/status", cam.cfg.pairing_code)[0] == 200


# ---- button and motion sensor -------------------------------------------------

def test_sos_button_creates_event_and_sounds_siren(cam):
    cam.hw.press_button()
    kinds = [e["kind"] for e in cam.events.since(0)]
    assert "sos_button" in kinds and cam.hw.siren_on


def test_motion_sensor_is_debounced(cam):
    cam.hw.trigger_motion()
    cam.hw.trigger_motion()
    cam.hw.trigger_motion()
    assert [e["kind"] for e in cam.events.since(0)].count("pir") == 1


# ---- video pipeline -----------------------------------------------------------

def test_capture_pipeline_flags(tmp_path):
    cfg = camcfg.CamConfig(width=1280, height=720, fps=10, bitrate_kbps=2000, hflip=True, audio=True)
    cmd = capture_pipeline(cfg)
    for part in ("rpicam-vid", "--width 1280", "--height 720", "--framerate 10", "--bitrate 2000000",
                 "--hflip", "-f alsa", "-c:a aac", "-c:v copy", "rtsp://127.0.0.1:8554/stream"):
        assert part in cmd, part
    assert "--vflip" not in cmd


def test_unsafe_audio_device_is_refused():
    with pytest.raises(ValueError):
        capture_pipeline(camcfg.CamConfig(audio=True, audio_device="x; rm -rf /"))


def test_mediamtx_config_protects_video():
    cfg = camcfg.CamConfig(pairing_code="ABC123XYZ9", rtsp_port=8554)
    text = mediamtx_config(cfg)
    assert "pass: ABC123XYZ9" in text and "ips: ['127.0.0.1', '::1']" in text
    assert "user: refours" in text and "action: read" in text
    assert snapshot_command(cfg)[-1] == "pipe:1"


def test_video_streamer_restarts_when_pipeline_dies():
    streamer = VideoStreamer("exit 1", retry_seconds=0.05)
    streamer.start()
    time.sleep(1.0)
    streamer.stop()
    assert streamer.restarts >= 2 and not streamer.running


def test_video_streamer_stops_a_running_pipeline():
    streamer = VideoStreamer("sleep 30", retry_seconds=0.05)
    streamer.start()
    time.sleep(0.5)
    assert streamer.running
    t0 = time.monotonic()
    streamer.stop()
    assert not streamer.running and time.monotonic() - t0 < 5


# ---- SafeEye talking to the camera --------------------------------------------

def test_client_end_to_end(cam):
    client = RefoursClient(f"http://127.0.0.1:{cam.server.port}", cam.cfg.pairing_code)
    assert client.info()["model"] == "Refours Cam"
    assert client.status()["siren_on"] is False
    assert client.siren(True, 3)["siren_on"] is True and cam.hw.siren_on
    assert client.snapshot() == JPEG
    cam.hw.press_button()
    kinds = [e["kind"] for e in client.events(0)["events"]]
    assert "sos_button" in kinds


def test_client_errors_are_friendly(cam):
    bad = RefoursClient(f"http://127.0.0.1:{cam.server.port}", "WRONG")
    with pytest.raises(RefoursError, match="wrong pairing code"):
        bad.status()
    gone = RefoursClient("http://127.0.0.1:1", "x", timeout=1)
    with pytest.raises(RefoursError, match="cannot reach"):
        gone.status()


def test_watcher_reports_sos_button_but_not_old_events(cam):
    cam.hw.press_button()  # happened BEFORE SafeEye connected: must be ignored
    client = RefoursClient(f"http://127.0.0.1:{cam.server.port}", cam.cfg.pairing_code)
    heard, got = [], threading.Event()
    watcher = RefoursWatcher("Gate", client, lambda why: (heard.append(why), got.set()), wait=2, retry=0.1,
                             log=lambda m: None)
    watcher.start()
    time.sleep(0.5)
    assert heard == []
    cam.hw.press_button()
    assert got.wait(4) and heard == ["SOS button pressed on Gate"]
    watcher.stop()


class ScriptedClient:
    """Pretends to be a camera that restarted (its event numbers started again from 1)."""

    def __init__(self):
        self.calls = []

    def status(self):
        return {"last_event_id": 5}

    def events(self, since, wait=0):
        self.calls.append(since)
        if since == 5:
            return {"events": [], "last_id": 1}  # camera rebooted: counter went back
        return {"events": [{"id": 2, "kind": "sos_button"}], "last_id": 2}


def test_watcher_recovers_when_camera_restarts():
    heard, got = [], threading.Event()
    watcher = RefoursWatcher("Gate", ScriptedClient(), lambda w: (heard.append(w), got.set()), wait=0, retry=0.05,
                             log=lambda m: None)
    watcher.start()
    assert got.wait(3)
    watcher.stop()


def test_watcher_survives_camera_going_offline():
    client = RefoursClient("http://127.0.0.1:1", "x", timeout=0.5)
    logs = []
    watcher = RefoursWatcher("Gate", client, lambda w: None, wait=0, retry=0.05, log=logs.append)
    watcher.start()
    time.sleep(0.5)
    assert watcher.is_alive()
    watcher.stop()


# ---- discovery parsing ---------------------------------------------------------

def test_parse_service():
    good = parse_service(["192.168.1.50"], 8080, {b"model": b"Refours Cam", b"id": b"ab12cd34", b"name": b"Gate",
                                                  b"api_port": b"8080", b"rtsp_port": b"8554", b"path": b"stream"})
    assert good == {"id": "ab12cd34", "name": "Gate", "host": "192.168.1.50", "api_port": 8080,
                    "rtsp_port": 8554, "path": "stream"}
    assert parse_service(["10.0.0.1"], 80, {b"model": b"Printer"}) is None
    assert parse_service([], 80, {b"model": b"Refours Cam"}) is None


def test_camera_announces_itself_and_safeeye_finds_it(tmp_path):
    from refourscam.discovery import advertise, local_ip, txt_records
    from safeeye_desktop.refours import discover

    cfg = camcfg.load_or_create(tmp_path)
    assert cfg.pairing_code not in json.dumps(txt_records(cfg))  # the code is never announced
    stop = advertise(cfg, address=local_ip())
    assert stop is not None, "zeroconf is not installed"
    try:
        time.sleep(1)
        found = discover(timeout=4)
    finally:
        stop()
    if not found:
        pytest.skip("this network blocks multicast (mDNS), so discovery cannot be tested here")
    assert found[0]["id"] == cfg.device_id and found[0]["api_port"] == cfg.api_port


# ---- pairing through the SafeEye command line ---------------------------------

def test_pair_adds_camera_and_hides_password(cam, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("SAFEEYE_HOME", str(tmp_path / "safeeye"))
    code, port = cam.cfg.pairing_code, str(cam.server.port)
    assert safeeye_main(["pair", "127.0.0.1", "--code", "WRONGCODE1", "--api-port", port]) == 1
    assert secfg.load().cameras == []
    assert safeeye_main(["pair", "127.0.0.1", "--code", code, "--api-port", port, "--name", "Gate",
                         "--siren-on-alert"]) == 0
    saved = secfg.load().cameras[0]
    assert saved.source == f"rtsp://refours:{code}@127.0.0.1:{cam.cfg.rtsp_port}/stream"
    assert saved.refours_api == f"http://127.0.0.1:{port}" and saved.siren_on_alert
    capsys.readouterr()
    assert safeeye_main(["list"]) == 0
    out = capsys.readouterr().out
    assert code not in out and "rtsp://refours:***@127.0.0.1" in out and "refours-cam" in out


def test_mask_url():
    assert secfg.mask_url("rtsp://u:secret@10.0.0.1:554/s") == "rtsp://u:***@10.0.0.1:554/s"
    assert secfg.mask_url("0") == "0" and secfg.mask_url("rtsp://10.0.0.1/s") == "rtsp://10.0.0.1/s"
    assert "secret" not in secfg.mask_url("Cannot open camera 'x' (rtsp://u:secret@h/s)")


# ---- alert hook: sound the camera's siren when SafeEye sees movement ----------

def test_alert_hook_is_called_and_cannot_break_watching(tmp_path):
    sys.path.insert(0, str(ROOT / "desktop" / "tests"))
    from test_desktop import make_video

    video = make_video(tmp_path / "scene.mp4")
    seen = []

    def hook(camera, reason):
        seen.append((camera.name, reason))
        raise RuntimeError("siren unreachable")

    c = secfg.CameraConfig("Gate", str(video), sensitivity="high")
    worker = CameraWorker(c, AlertStore(tmp_path), NullAlarm(), hour_fn=lambda: 12, log=lambda m: None, on_alert=hook)
    worker.run()
    assert seen == [("Gate", "Movement detected")] and worker.alerts_raised == 1
    assert len(list((tmp_path / "alerts").glob("*.mp4"))) == 1  # the clip was still saved


# ---- the real program ----------------------------------------------------------

def test_camera_program_runs_in_simulation_and_shuts_down(tmp_path):
    env = {**os.environ, "REFOURSCAM_HOME": str(tmp_path), "PYTHONPATH": str(ROOT / "refourscam")}
    proc = subprocess.Popen([sys.executable, "-m", "refourscam", "run", "--simulate"], env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    time.sleep(2.5)
    proc.send_signal(signal.SIGTERM)
    out, _ = proc.communicate(timeout=10)
    code = json.loads((tmp_path / "config.json").read_text())["pairing_code"]
    assert proc.returncode == 0 and "Refours Cam 1.0.0 running" in out and code in out
