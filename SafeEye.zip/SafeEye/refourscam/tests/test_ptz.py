"""Tests for the pan/tilt mount and SafeEye's auto-tracking.
Run:  python -m pytest refourscam/tests -q"""

import json
import math
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "refourscam"))
sys.path.insert(0, str(ROOT / "desktop"))
sys.path.insert(0, str(ROOT / "desktop" / "tests"))

from refourscam import config as camcfg  # noqa: E402
from refourscam.app import Camera  # noqa: E402
from refourscam.hal import FakeHardware  # noqa: E402
from refourscam.ptz import FakeDriver, PanTilt  # noqa: E402

from safeeye_desktop import config as secfg  # noqa: E402
from safeeye_desktop.__main__ import main as safeeye_main  # noqa: E402
from safeeye_desktop.alerts import NullAlarm  # noqa: E402
from safeeye_desktop.detector import MotionDetector  # noqa: E402
from safeeye_desktop.monitor import CameraWorker  # noqa: E402
from safeeye_desktop.refours import RefoursError  # noqa: E402
from safeeye_desktop.store import AlertStore  # noqa: E402
from safeeye_desktop.tracking import Tracker  # noqa: E402
from test_desktop import make_video  # noqa: E402


def fast_cfg(tmp_path, **over):
    cfg = camcfg.load_or_create(tmp_path)
    cfg.ptz_enabled = True
    cfg.steps_per_degree_pan = cfg.steps_per_degree_tilt = 10.0
    cfg.ptz_speed_dps = 100000.0
    for k, v in over.items():
        setattr(cfg, k, v)
    return cfg


@pytest.fixture
def mount(tmp_path):
    cfg = fast_cfg(tmp_path)
    driver = FakeDriver()
    m = PanTilt(cfg, driver)
    m.driver_ = driver
    yield m
    m.close()


@pytest.fixture
def ptz_cam(tmp_path):
    cfg = fast_cfg(tmp_path)
    ptz = PanTilt(cfg, FakeDriver())
    camera = Camera(cfg, FakeHardware(), api_port=0, host="127.0.0.1", ptz=ptz)
    camera.start()
    yield camera
    camera.stop()


def api(cam, path, code, method="GET", raw=None):
    req = urllib.request.Request(f"http://127.0.0.1:{cam.server.port}{path}", method=method, data=raw)
    if code:
        req.add_header("Authorization", f"Bearer {code}")
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def post(cam, body: dict, code=None):
    return api(cam, "/api/ptz", code or cam.cfg.pairing_code, "POST", json.dumps(body).encode())


# ---- the mount ---------------------------------------------------------------

def test_moves_to_the_exact_angle_with_the_right_number_of_steps(mount):
    assert mount.move_to(30, -10) == (30, -10)
    assert mount.wait_until_still()
    assert mount.position() == (30.0, -10.0)
    assert mount.driver_.pulses == {"pan": 300, "tilt": 100}


def test_soft_limits_clamp(mount):
    pan, tilt = mount.move_to(500, 500)
    assert (pan, tilt) == (mount.cfg.pan_max, mount.cfg.tilt_max)
    mount.wait_until_still()
    assert mount.position() == (mount.cfg.pan_max, mount.cfg.tilt_max)
    mount.move_to(-500, -500)
    mount.wait_until_still()
    assert mount.position() == (mount.cfg.pan_min, mount.cfg.tilt_min)


def test_quick_relative_moves_add_up_and_home_returns(mount):
    mount.move_by(5, 0)
    mount.move_by(5, 2)
    mount.wait_until_still()
    assert mount.position() == (10.0, 2.0)
    mount.home()
    mount.wait_until_still()
    assert mount.position() == (0.0, 0.0)
    assert mount.driver_.pulses["pan"] == 200  # 100 steps out, 100 back


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), 1e9])
def test_silly_angles_are_refused(mount, bad):
    with pytest.raises(ValueError):
        mount.move_to(bad, 0)
    assert mount.position() == (0.0, 0.0)


def test_patrol_visits_each_point_and_a_manual_move_stops_it(tmp_path):
    cfg = fast_cfg(tmp_path, patrol_points=[[10, 0], [-10, 0]], patrol_dwell_s=0.05)
    m = PanTilt(cfg, FakeDriver())
    seen = set()
    try:
        m.set_patrol(True)
        end = time.monotonic() + 4
        while time.monotonic() < end and seen != {10.0, -10.0}:
            seen.add(m.position()[0])
            time.sleep(0.005)
        assert {10.0, -10.0} <= seen
        m.move_to(0, 0)  # the user takes control
        assert not m.patrolling
        m.wait_until_still()
        time.sleep(0.3)
        assert m.position() == (0.0, 0.0)  # and it stays put
    finally:
        m.close()


# ---- the camera's API -----------------------------------------------------------

def test_api_moves_the_mount_and_needs_the_code(ptz_cam):
    assert api(ptz_cam, "/api/ptz", None)[0] == 401
    status, state = post(ptz_cam, {"pan": 20, "tilt": 5})
    assert status == 200
    ptz_cam.ptz.wait_until_still()
    status, state = api(ptz_cam, "/api/ptz", ptz_cam.cfg.pairing_code)
    assert (state["pan"], state["tilt"], state["moving"]) == (20.0, 5.0, False)
    assert state["limits"]["pan"] == [-90.0, 90.0]
    post(ptz_cam, {"dpan": -5})
    ptz_cam.ptz.wait_until_still()
    assert ptz_cam.ptz.position() == (15.0, 5.0)
    post(ptz_cam, {"home": True})
    ptz_cam.ptz.wait_until_still()
    assert ptz_cam.ptz.position() == (0.0, 0.0)
    assert post(ptz_cam, {"patrol": True})[1]["patrol"] is True
    assert post(ptz_cam, {"home": True})[1]["patrol"] is False  # going home ends patrol


def test_api_rejects_bad_input(ptz_cam):
    assert post(ptz_cam, {})[0] == 400
    assert post(ptz_cam, {"pan": "left"})[0] == 400
    status, _ = api(ptz_cam, "/api/ptz", ptz_cam.cfg.pairing_code, "POST", b'{"pan": NaN}')
    assert status == 400
    assert post(ptz_cam, {"dpan": 1e12})[0] == 400
    assert ptz_cam.ptz.position() == (0.0, 0.0)


def test_camera_without_a_mount_says_so_and_info_reports_view(tmp_path):
    cfg = camcfg.load_or_create(tmp_path)
    cam = Camera(cfg, FakeHardware(), api_port=0, host="127.0.0.1")
    cam.start()
    try:
        assert api(cam, "/api/ptz", cfg.pairing_code)[0] == 501
        info = api(cam, "/api/info", None)[1]
        assert info["ptz"] is False and info["hfov_deg"] == 55.0
    finally:
        cam.stop()


def test_info_reports_field_of_view_for_tracking(ptz_cam):
    info = api(ptz_cam, "/api/info", None)[1]
    expected = math.degrees(2 * math.atan(math.tan(math.radians(55) / 2) * 1080 / 1920))
    assert info["ptz"] is True and info["hfov_deg"] == 55.0 and abs(info["vfov_deg"] - expected) < 0.01


# ---- the tracker -----------------------------------------------------------------

class RecordingClient:
    def __init__(self, fail=False):
        self.moves, self.homes, self.fail = [], 0, fail

    def ptz_move(self, dpan, dtilt):
        if self.fail:
            raise RefoursError("offline")
        self.moves.append((dpan, dtilt))

    def ptz_home(self):
        self.homes += 1


def tracker(client, **kw):
    return Tracker(client, 55.0, 32.6, sync=True, log=lambda m: None, **kw)


def test_turns_toward_the_target_with_the_right_signs():
    c = RecordingClient()
    t = tracker(c)
    assert t.update(0.8, 0.3, 0.0)  # right of centre and above it
    dpan, dtilt = c.moves[0]
    assert dpan == 6.0                        # wanted 11.5 degrees, but one step is limited to 6
    assert dtilt == pytest.approx(0.2 * 32.6 * 0.7)  # up is positive
    t2, c2 = tracker(RecordingClient()), None
    c2 = t2.client
    t2.update(0.1, 0.9, 0.0)  # left and below
    assert c2.moves[0][0] < 0 and c2.moves[0][1] < 0


def test_small_errors_are_ignored():
    c = RecordingClient()
    assert not tracker(c).update(0.51, 0.5, 0.0) and c.moves == []


def test_waits_for_the_camera_to_settle_before_looking_again():
    c = RecordingClient()
    t = tracker(c)
    t.update(0.9, 0.5, 0.0)
    assert t.settling(0.5) and not t.settling(1.0)
    assert not t.update(0.9, 0.5, 0.1)  # too soon
    assert len(c.moves) == 1


def test_returns_home_once_after_a_quiet_minute():
    c = RecordingClient()
    t = tracker(c, home_after=60)
    assert not t.idle(5)  # never saw anything: nothing to undo
    t.update(0.9, 0.5, 10.0)
    assert not t.idle(40) and c.homes == 0
    assert t.idle(71) and c.homes == 1
    assert t.settling(75)  # the way home is a long turn: do not read it as movement
    assert not t.idle(200) and c.homes == 1


def test_a_camera_that_does_not_answer_is_logged_not_fatal():
    logs = []
    t = Tracker(RecordingClient(fail=True), 55, 32.6, sync=True, log=logs.append)
    assert t.update(0.9, 0.5, 0.0)
    assert t.commands == 0 and any("did not answer" in m for m in logs)


def test_motion_detector_reports_where_the_movement_is():
    import cv2
    import numpy as np

    det = MotionDetector(0.012)
    still = np.full((180, 320, 3), 90, np.uint8)
    det.update(still)
    moved = still.copy()
    cv2.rectangle(moved, (240, 30), (300, 90), (255, 255, 255), -1)  # upper right
    assert det.update(moved)
    cx, cy = det.centroid
    assert cx > 0.6 and cy < 0.5
    assert not det.update(moved) and det.centroid is None


def test_closed_loop_turns_to_a_target_and_settles_without_overshoot(tmp_path):
    """A target stands 20 degrees to the right. Camera view is 55 degrees wide."""
    cfg = fast_cfg(tmp_path)
    mount = PanTilt(cfg, FakeDriver())

    class Direct:
        def ptz_move(self, dpan, dtilt):
            mount.move_by(dpan, dtilt)
            mount.wait_until_still()

        def ptz_home(self):
            mount.home()

    t = Tracker(Direct(), 55.0, 32.6, sync=True, log=lambda m: None)
    target_deg, ts, worst = 20.0, 0.0, 0.0
    try:
        for _ in range(60):
            ts += 0.2
            if t.settling(ts):
                continue
            pan = mount.position()[0]
            worst = max(worst, pan)
            cx = 0.5 + (target_deg - pan) / 55.0
            t.update(cx, 0.5, ts)
        assert abs(mount.position()[0] - target_deg) < 2.0   # within the dead-band
        assert worst < target_deg + 0.5                       # never swung past the target
        assert t.commands <= 6                                # a few clean steps, no jitter
    finally:
        mount.close()


def test_tracker_moves_a_real_camera_over_the_network(ptz_cam):
    from safeeye_desktop.refours import RefoursClient

    client = RefoursClient(f"http://127.0.0.1:{ptz_cam.server.port}", ptz_cam.cfg.pairing_code)
    assert tracker(client).update(0.8, 0.5, 0.0)
    ptz_cam.ptz.wait_until_still()
    assert ptz_cam.ptz.position()[0] == 6.0


# ---- the worker with a tracker ---------------------------------------------------

class FakeTracker:
    def __init__(self, settle_until=0.0):
        self.settle_until, self.updates, self.idles = settle_until, [], 0

    def settling(self, ts):
        return ts < self.settle_until

    def update(self, cx, cy, ts):
        self.updates.append((cx, cy, ts))

    def idle(self, ts):
        self.idles += 1


def run_with_tracker(tmp_path, tr):
    video = make_video(tmp_path / "scene.mp4")
    cam = secfg.CameraConfig("Gate", str(video), sensitivity="high")
    w = CameraWorker(cam, AlertStore(tmp_path), NullAlarm(), hour_fn=lambda: 12, log=lambda m: None, tracker=tr)
    w.run()
    return w


def test_worker_feeds_the_tracker_the_movement_position(tmp_path):
    tr = FakeTracker()
    w = run_with_tracker(tmp_path, tr)
    assert w.alerts_raised == 1 and tr.updates and tr.idles > 0
    assert all(0 <= cx <= 1 and 0 <= cy <= 1 for cx, cy, _ in tr.updates)


def test_worker_ignores_the_picture_while_the_camera_is_turning(tmp_path):
    w = run_with_tracker(tmp_path, FakeTracker(settle_until=1e9))  # always turning
    assert w.alerts_raised == 0  # a shifting picture must never raise an alarm
    tr = FakeTracker(settle_until=5.0)  # turning until 5 s; real movement starts at 3 s
    w2 = run_with_tracker(tmp_path / "second", tr) if (tmp_path / "second").mkdir() is None else None
    assert w2.alerts_raised == 1 and min(ts for _, _, ts in tr.updates) >= 5.0


# ---- pairing and manual control through the command line -----------------------

def test_pair_with_auto_track_and_aim_by_hand(ptz_cam, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("SAFEEYE_HOME", str(tmp_path / "safeeye"))
    port, code = str(ptz_cam.server.port), ptz_cam.cfg.pairing_code
    assert safeeye_main(["pair", "127.0.0.1", "--code", code, "--api-port", port, "--name", "Gate",
                         "--auto-track"]) == 0
    saved = secfg.load().cameras[0]
    assert saved.auto_track and saved.hfov_deg == 55.0 and 32 < saved.vfov_deg < 33

    assert safeeye_main(["ptz", "Gate", "--pan", "15", "--tilt", "5"]) == 0
    ptz_cam.ptz.wait_until_still()
    assert ptz_cam.ptz.position() == (15.0, 5.0)
    assert safeeye_main(["ptz", "Gate", "--pan", "-20"]) == 0   # tilt is kept as it was
    ptz_cam.ptz.wait_until_still()
    assert ptz_cam.ptz.position() == (-20.0, 5.0)
    assert safeeye_main(["ptz", "Gate", "--home"]) == 0
    ptz_cam.ptz.wait_until_still()
    assert ptz_cam.ptz.position() == (0.0, 0.0)
    capsys.readouterr()
    assert safeeye_main(["ptz", "Gate"]) == 0 and "pan 0.0" in capsys.readouterr().out
    assert safeeye_main(["ptz", "Nobody", "--home"]) == 1


def test_auto_track_is_refused_for_a_camera_without_a_mount(tmp_path, monkeypatch):
    monkeypatch.setenv("SAFEEYE_HOME", str(tmp_path / "safeeye"))
    cfg = camcfg.load_or_create(tmp_path / "cam")
    cam = Camera(cfg, FakeHardware(), api_port=0, host="127.0.0.1")
    cam.start()
    try:
        assert safeeye_main(["pair", "127.0.0.1", "--code", cfg.pairing_code, "--api-port", str(cam.server.port),
                             "--auto-track"]) == 1
        assert secfg.load().cameras == []
    finally:
        cam.stop()
