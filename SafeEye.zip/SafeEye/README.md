# SafeEye by Refours Systems

Camera safety software: movement and object detection, alerts with snapshots and short clips, live captions, danger-word detection, and an SOS that sends your location to trusted contacts.

| Version | Where | Folder |
|---|---|---|
| Android phone app | Android 7+ | `app/` |
| Wear OS watch (SOS button) | Wear OS 3+ | `wear/` |
| Desktop (Windows, macOS, Linux) | any computer with Python | `desktop/` |
| **Refours Cam** (our own camera) | Raspberry Pi | `refourscam/` (start with `refourscam/HARDWARE.md`) |

---

## Refours Cam: our own camera

A camera you build with a Raspberry Pi that is made to work with SafeEye. It streams video (with sound if you add a microphone), has a motion sensor, a siren and an **SOS button** (hold 2 seconds). SafeEye finds it on your Wi-Fi automatically and pairs with a 10-character code.

- **Build it:** `refourscam/HARDWARE.md` has the parts list, wiring, install steps, and a table of how far each lens can see.
- **Install on the Pi:** `sudo ./install.sh` inside `refourscam/`. It prints the pairing code.
- **Pair:** Android: IP cameras > Find Refours Cams. Desktop: `run discover`, then `run pair <address> --code <code>`.
- **What SafeEye does with it:** watches its video like any IP camera; on desktop it also listens for the SOS button (siren plus SOS to your contacts) and can sound the camera's siren when it sees movement (`--siren-on-alert`).
- **Pan/tilt auto-tracking (optional):** add a motorised mount and the camera turns toward movement, so one long-range camera covers a wide area (`run pair ... --auto-track`; see `refourscam/HARDWARE.md`, section 8). Desktop only for now.
- **Status:** the camera software and the SafeEye pairing are tested on a computer (73 automated tests across the camera and desktop software, including real network discovery and a simulated tracking loop). **It has not been run on a real Raspberry Pi with a real camera yet.** The installer, video pipeline, GPIO wiring and the Android pairing screen are untested on hardware.
- **Security:** keep the pairing code private and never forward the camera's ports to the internet (use a VPN to reach it from outside).
- Try it with no hardware: `PYTHONPATH=refourscam REFOURSCAM_HOME=/tmp/cam python3 -m refourscam run --simulate`

---

## Android + watch

### Install and run
1. Install Android Studio (latest). File > Open > select this `SafeEye` folder and let Gradle sync.
2. Plug in a phone (USB debugging on) and press Run. Accept the camera, microphone, location and SMS permissions.
3. Tap **Contacts** and save up to 5 trusted numbers (international format, e.g. +254700000000).
4. **Run in background** keeps watching with the screen off (a notification shows while active).
5. **IP cameras:** add each camera's name and RTSP address (e.g. `rtsp://user:pass@192.168.1.10:554/stream1`). Tap a camera to **View live**, change its **Settings**, or **Remove** it. **Start background monitoring** watches all of them at once and reconnects by itself if a stream drops.
6. **Per-camera settings:** sensitivity (low / medium / high), save a short clip or only a snapshot, and the hours to watch (e.g. 20 to 6 = overnight).
7. **Alert history:** every alert, newest first, with its snapshot. Tap one to enlarge it or play its clip, and **Share** it to a contact through WhatsApp, email, etc. Everything stays on the phone; the latest 200 alerts are kept.
8. **Watch SOS:** run the `wear` configuration on a paired Wear OS watch (the phone app must also be installed). Press and HOLD the red button; the phone sends the SOS with your location.

### What it does
- **Detection:** ML Kit on-device AI finds prominent objects, tracks them and draws boxes. Movement is detected from frame changes.
- **Captions and sound:** live speech-to-text. Loud sounds and danger words ("help", "fire", "msaada", "mwizi"...) trigger the alarm.
- **Lost / SOS:** the red button sends your GPS position as a Google Maps link by SMS (works without internet) and opens WhatsApp with the message ready.
- **Alerts:** siren, vibration and notifications, with a cooldown to avoid spam.
- **Background mode:** a danger word also auto-sends an SOS, at most once every 5 minutes.

### Android limits
- **Not compiled yet.** This code was written without access to an Android build environment. Expect to fix a few small errors on the first Gradle sync, and test on a real phone before relying on it.
- **It does not recognise "person".** ML Kit's default model only gives broad categories (Fashion good, Food, Home good, Place, Plant). SafeEye therefore alerts on any detected object that moves, and "people only" is not available on Android. A TensorFlow Lite / MediaPipe EfficientDet or YOLO model is the fix (see Roadmap). The desktop version already detects people properly.
- **Clips are picture sequences, not true video.** About 3 seconds before and 8 seconds after the alert, one picture per second, played back like a slideshow. IP cameras only.
- Sound and danger-word alerts are logged without a picture.
- IP cameras are analysed about once every 0.7 seconds. Many cameras at once use a lot of battery and data: keep the phone charged and on stable Wi-Fi, and use each camera's low-resolution sub-stream if it has one. Cameras on your home network (192.168.x.x) are only reachable while the phone is on that network.
- Watch SOS: SMS goes out even if the app is closed, but the location may be missing unless "Run in background" is on. WhatsApp cannot send automatically (the user taps send) and only opens when the app is visible.
- Background mode must be started while the app is open (Android rule). Some phones (Xiaomi, Tecno, Infinix...) kill background apps: turn off battery optimisation for SafeEye.

---

## Desktop (Windows, macOS, Linux)

Runs from the command line, watches any number of cameras, and works without a screen (for example on a spare computer or mini PC). Tested here with automated tests on synthetic video; see "Desktop limits".

### Install
Install Python 3.9 or newer (Windows: python.org, tick "Add to PATH"), then in the `desktop` folder:

- **Windows:** double-click `install.bat`
- **macOS / Linux:** `./install.sh`

### Use
```
run add-camera Webcam 0                                   # first webcam
run add-camera Gate rtsp://user:pass@192.168.1.10/stream1 --sensitivity high --hours 20-6 --people-only
run list
run run --show                                            # watch, with live preview windows (q to quit)
run run                                                   # watch with no windows
run history                                               # recent alerts with file paths
run sos "I need help"                                     # send an SOS now
run test-alarm
```
(`run` means `run.bat` on Windows and `./run.sh` on macOS/Linux.) Camera options: `--sensitivity low|medium|high`, `--no-clips`, `--people-only`, `--hours START-END`. A source can be a webcam number, an `rtsp://` address or a video file.

Alerts are saved in `~/.safeeye/alerts/` (override with the `SAFEEYE_HOME` variable): a snapshot, plus a real **MP4 clip** with 3 seconds before and 8 seconds after the alert.

### Detection
- Default: OpenCV's built-in **person detector**. No download. Decent for people standing or walking upright.
- Better: `pip install -r requirements-extra.txt` adds **YOLOv8** (people, vehicles, animals and about 80 other things). It downloads a ~6 MB model on first use and is picked automatically. Force one with `run run --detector yolo|hog|none`.

### SOS and lost-person help (desktop)
Edit `~/.safeeye/config.json` (created when you add a camera). Fill in any of these; all configured channels are used:
- **Telegram:** create a bot with @BotFather, set `telegram_token` (or the `SAFEEYE_TELEGRAM_TOKEN` variable) and the `telegram_chat_ids` that should receive alerts. Messages arrive instantly on phones and watches.
- **Email:** `smtp_host`, `smtp_port`, `smtp_user`, `email_to`, and the password in `smtp_password` (or `SAFEEYE_SMTP_PASSWORD`).
- **WhatsApp:** `whatsapp_numbers`; `run sos --whatsapp` opens WhatsApp with the message ready (you tap send).
- **Location:** a computer has no GPS, so set `location` to `"lat,lon"` or an address. The message includes a map link and a directions link. `use_ip_location: true` asks a public service (ipwho.is) for a city-level position instead.

The config file may hold secrets, so SafeEye restricts it to your user account where the system allows it.

### Captions and danger words (optional)
`pip install SpeechRecognition PyAudio`, then `run run --captions`. **This sends microphone audio to Google's speech service**, so it is off unless you ask for it. A danger word or loud sound sounds the alarm and sends an SOS (at most once every 5 minutes).

### Desktop limits
- Tested: configuration, schedules, sensitivity, movement detection, alerts with snapshots and MP4 clips on a video file, cooldown, history pruning, the SOS channels (with simulated servers), and the command line. Run them with `python -m pytest desktop/tests`.
- **Not tested on real hardware:** webcams, RTSP cameras, the siren on Windows/macOS, live preview windows, microphone captions, YOLO, and real Telegram/email delivery.
- Movement alerts depend on the camera view: moving trees, shadows and lights can trigger them. Use lower sensitivity or a schedule if that happens.

---

## Range: the honest answer
Detection distance is set by the lens, the sensor and the resolution, not by software. A phone or webcam sees people reliably only to tens of metres. To watch 1 km or more, connect a telephoto/PTZ or thermal camera that offers an RTSP stream (both versions can read one), or build a Refours Cam Zoom with a 100 mm lens (see the calculated table in `refourscam/HARDWARE.md`: a person is about 39 pixels tall at 1 km with a 100 mm lens, but only 63 m of width is in view). A distant subject is limited by how many pixels it covers. Radar and other non-video sensors are not supported yet.

## Privacy and law
Record and caption audio and video only where you have consent; laws on recording differ by country. Pictures and clips stay on your own device unless you share them.

## Android: Refours Cam notes
- **Find Refours Cams** needs the phone on the same Wi-Fi. The pairing check talks to the camera over plain HTTP on your local network, so the app allows cleartext traffic. Use it only on networks you trust.
- The Android app does not yet listen for the camera's SOS button (desktop does).

## Roadmap
1. Person/vehicle model on Android (TensorFlow Lite / MediaPipe EfficientDet), true MP4 clips on Android, and scream/gunshot sound classification (YAMNet)
2. Detection zones (ignore a road or a tree) on both versions
3. PTZ control and radar sensor input for long range
4. Watch alerts and heart-rate trigger; web version
5. Cloud push alerts (Firebase) and the WhatsApp Business API for automatic WhatsApp sending
