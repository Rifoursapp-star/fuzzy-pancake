#!/usr/bin/env sh
# SafeEye desktop installer for macOS and Linux. Needs Python 3.9+.
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
cat <<'EOF'

SafeEye is installed. Next:
  ./run.sh add-camera Webcam 0
  ./run.sh run --show
EOF
