@echo off
cd /d "%~dp0"
.venv\Scripts\python -m safeeye_desktop %*
