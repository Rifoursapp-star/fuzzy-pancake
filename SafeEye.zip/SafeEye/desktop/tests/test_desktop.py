"""Tests for the desktop version. Run:  python -m pytest desktop/tests -q"""

import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from safeeye_desktop import config as cfgmod  # noqa: E402
from safeeye_desktop.__main__ import main  # noqa: E402
from safeeye_desktop.alerts import Alarm, NullAlarm  # noqa: E402
from safeeye_desktop.detector import Detection, HogPersonDetector, MotionDetector  # noqa: E402
from safeeye_desktop.monitor import CameraWorker  # noqa: E402
from safeeye_desktop.sos import build_message, send_sos  # noqa: E402
from safeeye_desktop.store import AlertStore  # noqa: E402

FPS = 15


def make_video(path: Path, seconds=14, motion_from=3.0, fps=FPS, w=320, h=180):
    """Static grey scene; from motion_from seconds a white square runs across it."""
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    assert writer.isOpened(), "OpenCV cannot write MP4 here"
    for i in range(int(seconds * fps)):
        frame = np.full((h, w, 3), 90, np.uint8)
        if i / fps >= motion_from:
            x = (i * 16) % (w - 80)
            cv2.rectangle(frame, (x, 50), (x + 80, 130), (255, 255, 255), -1)
        writer.write(frame)
    writer.release()
    return path


def run_worker(tmp_path, video, **cam_kwargs):
    cam = cfgmod.CameraConfig(name="Test", source=str(video), sensitivity="high", **cam_kwargs)
    store = AlertStore(tmp_path)
    worker = CameraWorker(cam, store, NullAlarm(), detector=cam_kwargs.pop("detector", None),
                          hour_fn=lambda: 12, log=lambda _m: None)
    return worker, store


# ---- configuration --------------------------------------------------------

def test_schedule_always_daytime_and_overnight():
    always = cfgmod.CameraConfig("a", "0")
    assert all(always.active_at(h) for h in range(24))
    day = cfgmod.CameraConfig("d", "0", start_hour=8, end_hour=18)
    assert day.active_at(8) and day.active_at(17) and not day.active_at(18) and not day.active_at(3)
    night = cfgmod.CameraConfig("n", "0", start_hour=20, end_hour=6)
    assert night.active_at(23) and night.active_at(0) and night.active_at(5)
    assert not night.active_at(6) and not night.active_at(12) and not night.active_at(19)


def test_sensitivity_order():
    t = {s: cfgmod.CameraConfig("x", "0", sensitivity=s).threshold for s in ("low", "medium", "high")}
    assert t["low"] > t["medium"] > t["high"]
    assert cfgmod.CameraConfig("x", "0", sensitivity="bogus").threshold == t["medium"]


def test_config_roundtrip_and_unknown_keys(tmp_path):
    cfg = cfgmod.Config(cameras=[cfgmod.CameraConfig("Gate", "rtsp://u:p@10.0.0.5/s", people_only=True,
                                                     start_hour=20, end_hour=6)])
    cfg.sos.whatsapp_numbers = ["+254700000000"]
    cfgmod.save(cfg, tmp_path)
    data = json.loads((tmp_path / "config.json").read_text())
    data["cameras"][0]["future_option"] = 1  # from a newer version: must not crash
    (tmp_path / "config.json").write_text(json.dumps(data))
    loaded = cfgmod.load(tmp_path)
    assert loaded.cameras[0].people_only and loaded.cameras[0].start_hour == 20
    assert loaded.sos.whatsapp_numbers == ["+254700000000"]


# ---- movement detection ---------------------------------------------------

def test_motion_detector_static_vs_moving():
    det = MotionDetector(0.03)
    still = np.full((180, 320, 3), 90, np.uint8)
    assert not det.update(still) and not det.update(still)
    moved = still.copy()
    cv2.rectangle(moved, (100, 40), (220, 140), (255, 255, 255), -1)
    assert det.update(moved)


def test_low_sensitivity_ignores_small_changes():
    still = np.full((180, 320, 3), 90, np.uint8)
    small = still.copy()
    cv2.rectangle(small, (10, 10), (40, 40), (255, 255, 255), -1)  # ~2.8% of the picture
    low, high = MotionDetector(0.08), MotionDetector(0.012)
    for d in (low, high):
        d.update(still)
    assert not low.update(small)
    assert high.update(small)


# ---- the camera worker, end to end on a video file ------------------------

def test_worker_raises_alert_with_snapshot_and_clip(tmp_path):
    video = make_video(tmp_path / "scene.mp4")
    worker, store = run_worker(tmp_path, video)
    worker.run()  # runs in this thread; ends when the file ends
    events = store.list()
    assert worker.alerts_raised == 1 and len(events) == 1  # cooldown: one alert, not dozens
    e = events[0]
    assert (store.dir / e["snapshot"]).exists()
    assert e["reason"] == "Movement detected"
    clip = cv2.VideoCapture(str(store.dir / e["clip"]))
    frames = int(clip.get(cv2.CAP_PROP_FRAME_COUNT))
    # 3 s before the alert is not all available (alert is at ~3 s) + 8 s after: a real clip.
    assert frames > 60, frames
    ok, _ = clip.read()
    assert ok
    clip.release()


def test_no_alert_on_static_scene(tmp_path):
    video = make_video(tmp_path / "still.mp4", motion_from=999)
    worker, store = run_worker(tmp_path, video)
    worker.run()
    assert worker.alerts_raised == 0 and store.list() == []


def test_snapshot_only_when_clips_off(tmp_path):
    video = make_video(tmp_path / "scene.mp4")
    worker, store = run_worker(tmp_path, video, clips=False)
    worker.run()
    e = store.list()[0]
    assert "clip" not in e and not list(store.dir.glob("*.mp4"))


def test_schedule_blocks_alerts_outside_hours(tmp_path):
    video = make_video(tmp_path / "scene.mp4")
    cam = cfgmod.CameraConfig("Night", str(video), sensitivity="high", start_hour=20, end_hour=6)
    store = AlertStore(tmp_path)
    worker = CameraWorker(cam, store, NullAlarm(), hour_fn=lambda: 12, log=lambda _m: None)
    worker.run()
    assert worker.alerts_raised == 0
    worker2 = CameraWorker(cam, store, NullAlarm(), hour_fn=lambda: 23, log=lambda _m: None)
    worker2.run()
    assert worker2.alerts_raised == 1


class StubDetector:
    def __init__(self, found):
        self.found = found

    def detect(self, _frame):
        return self.found


def test_people_only_filters_and_describes(tmp_path):
    video = make_video(tmp_path / "scene.mp4")
    cam = cfgmod.CameraConfig("Yard", str(video), sensitivity="high", people_only=True)
    store = AlertStore(tmp_path)
    w1 = CameraWorker(cam, store, NullAlarm(), detector=StubDetector([Detection("dog", 0.9, (0, 0, 5, 5))]),
                      hour_fn=lambda: 12, log=lambda _m: None)
    w1.run()
    assert w1.alerts_raised == 0  # a dog is not a person
    w2 = CameraWorker(cam, store, NullAlarm(), detector=StubDetector([Detection("person", 0.9, (0, 0, 5, 5))]),
                      hour_fn=lambda: 12, log=lambda _m: None)
    w2.run()
    assert w2.alerts_raised == 1 and "1 person" in store.list()[0]["reason"]


def test_missing_source_is_reported_not_crashed(tmp_path):
    cam = cfgmod.CameraConfig("Ghost", str(tmp_path / "nope.mp4"))
    messages = []
    worker = CameraWorker(cam, AlertStore(tmp_path), NullAlarm(), log=messages.append)
    worker.RETRY_SECONDS = 0.01
    worker.start()
    for _ in range(200):
        if any("Cannot open" in m for m in messages):
            break
        worker.done.wait(0.01)
    worker.stop()
    worker.join(timeout=3)
    assert any("Cannot open camera 'Ghost'" in m for m in messages)
    assert worker.done.is_set()


def test_hog_detector_smoke():
    assert HogPersonDetector().detect(np.full((360, 640, 3), 120, np.uint8)) == []


# ---- history storage ------------------------------------------------------

def test_store_prunes_to_200_and_deletes_files(tmp_path):
    store = AlertStore(tmp_path)
    img = np.zeros((20, 20, 3), np.uint8)
    for i in range(205):
        store.add("cam", f"event {i}", img)
    events = store.list()
    assert len(events) == 200
    assert events[0]["reason"] == "event 204"  # newest first
    assert len(list(store.dir.glob("*.jpg"))) == 200


# ---- SOS ------------------------------------------------------------------

def test_message_contains_location_and_directions():
    msg = build_message("Heard \"help\"", "-1.2921,36.8219")
    assert "maps.google.com/?q=-1.2921%2C36.8219" in msg and "destination=" in msg and "help" in msg
    assert "not available" in build_message("x", None)


def test_sos_reports_when_nothing_configured():
    assert send_sos(cfgmod.SosConfig(), "test") == [("none", False, "no SOS channel is configured (see README)")]


class FakeResp:
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def test_sos_telegram_email_whatsapp(monkeypatch):
    monkeypatch.delenv("SAFEEYE_TELEGRAM_TOKEN", raising=False)
    monkeypatch.setenv("SAFEEYE_SMTP_PASSWORD", "from-env")
    cfg = cfgmod.SosConfig(telegram_token="TOKEN", telegram_chat_ids=["111", "222"],
                           smtp_host="smtp.example.com", smtp_user="me@example.com", email_to=["a@x.com"],
                           whatsapp_numbers=["+254 700-000000"], location="-1.29,36.82")
    calls, sent, opened = [], [], []

    def fake_urlopen(url, data=None, timeout=None):
        calls.append((url, data))
        return FakeResp()

    class FakeSMTP:
        def __init__(self, host, port, **kw): self.host, self.port = host, port
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def starttls(self, **kw): sent.append("tls")
        def login(self, user, pw): sent.append(("login", user, pw))
        def send_message(self, m): sent.append(("mail", m["To"], m.get_content()))

    results = send_sos(cfg, "test", open_whatsapp=True, urlopen=fake_urlopen, smtp_class=FakeSMTP,
                       browser_open=opened.append)
    assert [(c, ok) for c, ok, _ in results] == [("telegram", True), ("telegram", True), ("email", True),
                                                 ("whatsapp", True)]
    assert calls[0][0] == "https://api.telegram.org/botTOKEN/sendMessage" and b"chat_id=111" in calls[0][1]
    assert ("login", "me@example.com", "from-env") in sent and "tls" in sent
    assert opened[0].startswith("https://wa.me/254700000000?text=")


def test_sos_one_failing_channel_does_not_stop_others():
    cfg = cfgmod.SosConfig(telegram_token="T", telegram_chat_ids=["1"], whatsapp_numbers=["+1555"], location="1,2")

    def boom(*a, **k):
        raise OSError("offline")

    results = send_sos(cfg, "x", open_whatsapp=True, urlopen=boom, browser_open=lambda u: None)
    assert results[0][:2] == ("telegram", False) and results[1][:2] == ("whatsapp", True)


# ---- alarm and command line ----------------------------------------------

def test_alarm_cooldown(tmp_path):
    alarm = Alarm(tmp_path, cooldown=60, enabled=False)
    assert alarm.sound() is True and alarm.sound() is False


def test_cli_add_list_remove(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("SAFEEYE_HOME", str(tmp_path))
    assert main(["add-camera", "Gate", "rtsp://u:p@10.0.0.5/s", "--sensitivity", "high", "--hours", "20-6",
                 "--people-only", "--no-clips"]) == 0
    cam = cfgmod.load(tmp_path).cameras[0]
    assert (cam.sensitivity, cam.start_hour, cam.end_hour, cam.people_only, cam.clips) == ("high", 20, 6, True, False)
    assert main(["add-camera", "Gate", "0"]) == 1  # duplicate name
    assert main(["add-camera", "Bad", "0", "--hours", "25-6"]) == 2
    assert main(["list"]) == 0 and "Gate" in capsys.readouterr().out
    assert main(["remove-camera", "Gate"]) == 0 and cfgmod.load(tmp_path).cameras == []
    assert main(["run"]) == 1  # no cameras: friendly failure
    assert main(["history"]) == 0
