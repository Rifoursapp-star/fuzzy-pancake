"""SOS: send "I need help" with a location to trusted contacts."""

from __future__ import annotations

import json
import os
import smtplib
import ssl
import urllib.parse
import urllib.request
import webbrowser
from email.message import EmailMessage

from .config import SosConfig


def maps_link(location: str) -> str:
    """Google Maps link for 'lat,lon' or a place name."""
    return "https://maps.google.com/?q=" + urllib.parse.quote(location.strip())


def directions_link(location: str) -> str:
    """Link that opens turn-by-turn directions to the location."""
    return "https://www.google.com/maps/dir/?api=1&destination=" + urllib.parse.quote(location.strip())


def ip_location(urlopen=urllib.request.urlopen) -> str | None:
    """City-level location from the public IP address. Contacts a third-party service."""
    try:
        with urlopen("https://ipwho.is/", timeout=5) as resp:
            data = json.load(resp)
        if data.get("success"):
            return f"{data['latitude']},{data['longitude']}"
    except Exception:
        pass
    return None


def build_message(reason: str, location: str | None) -> str:
    if location:
        where = f"My location: {maps_link(location)} (directions: {directions_link(location)})"
    else:
        where = "My location is not available."
    return f"SOS from SafeEye by Refours Systems: {reason}. I need help. {where}"


def send_sos(
    cfg: SosConfig,
    reason: str,
    *,
    open_whatsapp: bool = False,
    urlopen=urllib.request.urlopen,
    smtp_class=smtplib.SMTP,
    smtp_ssl_class=smtplib.SMTP_SSL,
    browser_open=webbrowser.open,
) -> list[tuple[str, bool, str]]:
    """Tries every configured channel. Returns (channel, succeeded, detail) for each."""
    location = cfg.location.strip() or (ip_location(urlopen) if cfg.use_ip_location else None)
    message = build_message(reason, location)
    results: list[tuple[str, bool, str]] = []

    token = os.environ.get("SAFEEYE_TELEGRAM_TOKEN") or cfg.telegram_token
    if token and cfg.telegram_chat_ids:
        for chat_id in cfg.telegram_chat_ids:
            try:
                body = urllib.parse.urlencode({"chat_id": chat_id, "text": message}).encode()
                with urlopen(f"https://api.telegram.org/bot{token}/sendMessage", data=body, timeout=15) as resp:
                    ok = 200 <= getattr(resp, "status", 200) < 300
                results.append(("telegram", ok, chat_id))
            except Exception as exc:
                results.append(("telegram", False, f"{chat_id}: {type(exc).__name__}"))

    if cfg.smtp_host and cfg.email_to:
        password = os.environ.get("SAFEEYE_SMTP_PASSWORD") or cfg.smtp_password
        try:
            mail = EmailMessage()
            mail["Subject"] = "SafeEye SOS"
            mail["From"] = cfg.smtp_user or "safeeye@localhost"
            mail["To"] = ", ".join(cfg.email_to)
            mail.set_content(message)
            if cfg.smtp_port == 465:
                server = smtp_ssl_class(cfg.smtp_host, cfg.smtp_port, context=ssl.create_default_context(), timeout=20)
            else:
                server = smtp_class(cfg.smtp_host, cfg.smtp_port, timeout=20)
            with server:
                if cfg.smtp_port != 465:
                    server.starttls(context=ssl.create_default_context())
                if cfg.smtp_user:
                    server.login(cfg.smtp_user, password)
                server.send_message(mail)
            results.append(("email", True, ", ".join(cfg.email_to)))
        except Exception as exc:
            results.append(("email", False, type(exc).__name__))

    if open_whatsapp and cfg.whatsapp_numbers:
        digits = "".join(ch for ch in cfg.whatsapp_numbers[0] if ch.isdigit())
        try:
            browser_open(f"https://wa.me/{digits}?text={urllib.parse.quote(message)}")
            results.append(("whatsapp", True, "opened - press send"))  # WhatsApp needs a tap to send
        except Exception as exc:
            results.append(("whatsapp", False, type(exc).__name__))

    if not results:
        results.append(("none", False, "no SOS channel is configured (see README)"))
    return results
