"""Local danger alarm (siren sound) and desktop notifications. Best effort on every OS."""

from __future__ import annotations

import shutil
import subprocess
import sys
import threading
import time
import wave
from pathlib import Path

import numpy as np


def _make_siren(path: Path) -> None:
    rate = 22050
    parts = []
    for freq in (880, 660) * 3:
        t = np.linspace(0, 0.4, int(rate * 0.4), endpoint=False)
        parts.append(0.6 * np.sin(2 * np.pi * freq * t))
    samples = (np.concatenate(parts) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        wav.writeframes(samples.tobytes())


class Alarm:
    """Plays a siren and shows a notification, at most once per cooldown."""

    def __init__(self, home: Path, cooldown: float = 8.0, enabled: bool = True):
        self.cooldown = cooldown
        self.enabled = enabled
        self._last = 0.0
        self._lock = threading.Lock()
        self._wav = home / "siren.wav"

    def sound(self, title: str = "SafeEye", message: str = "") -> bool:
        with self._lock:
            now = time.monotonic()
            if now - self._last < self.cooldown and self._last:
                return False
            self._last = now
        if self.enabled:
            self._play()
            notify(title, message)
        return True

    def _play(self) -> None:
        try:
            if not self._wav.exists():
                _make_siren(self._wav)
            if sys.platform == "win32":
                import winsound

                winsound.PlaySound(str(self._wav), winsound.SND_FILENAME | winsound.SND_ASYNC)
            elif sys.platform == "darwin":
                subprocess.Popen(["afplay", str(self._wav)])
            else:
                for player in (["paplay"], ["aplay", "-q"], ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"]):
                    if shutil.which(player[0]):
                        subprocess.Popen(player + [str(self._wav)], stderr=subprocess.DEVNULL)
                        return
                print("\a", end="", flush=True)
        except Exception:
            print("\a", end="", flush=True)


class NullAlarm(Alarm):
    """Silent alarm for tests and headless servers."""

    def __init__(self) -> None:
        self.cooldown = 0.0
        self.enabled = False
        self.count = 0
        self._last = 0.0
        self._lock = threading.Lock()

    def sound(self, title: str = "", message: str = "") -> bool:
        self.count += 1
        return True


def notify(title: str, message: str) -> None:
    try:
        if sys.platform == "darwin":
            safe = lambda s: s.replace("\\", "\\\\").replace('"', '\\"')
            subprocess.Popen(["osascript", "-e", f'display notification "{safe(message)}" with title "{safe(title)}"'])
        elif sys.platform.startswith("linux") and shutil.which("notify-send"):
            subprocess.Popen(["notify-send", title, message])
        # Windows: the siren and the console line are the alert.
    except Exception:
        pass
