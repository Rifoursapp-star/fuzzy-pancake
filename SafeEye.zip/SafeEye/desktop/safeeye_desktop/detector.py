"""Movement and object detection."""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class Detection:
    label: str
    confidence: float
    box: tuple[int, int, int, int]  # x, y, width, height


class MotionDetector:
    """Flags movement when enough of the picture changes between two frames."""

    def __init__(self, threshold: float):
        self.threshold = threshold
        self._previous: np.ndarray | None = None
        # Centre of the moving area as (x, y), each 0-1 across the picture. None when still.
        self.centroid: tuple[float, float] | None = None

    def reset(self) -> None:
        self._previous = None
        self.centroid = None

    def update(self, frame: np.ndarray) -> bool:
        small = cv2.resize(frame, (160, 90), interpolation=cv2.INTER_AREA)
        gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        previous, self._previous = self._previous, gray
        self.centroid = None
        if previous is None:
            return False
        mask = cv2.absdiff(gray, previous) > 25
        moving = float(np.mean(mask)) > self.threshold
        if moving:
            ys, xs = np.nonzero(mask)
            self.centroid = (float(xs.mean()) / mask.shape[1], float(ys.mean()) / mask.shape[0])
        return moving


class HogPersonDetector:
    """People detector built into OpenCV. Needs no download, works on any computer.
    Less accurate than YOLO, and best on people standing or walking upright."""

    name = "hog"

    def __init__(self) -> None:
        self._hog = cv2.HOGDescriptor()
        self._hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

    def detect(self, frame: np.ndarray) -> list[Detection]:
        h, w = frame.shape[:2]
        scale = 640 / w if w > 640 else 1.0
        small = cv2.resize(frame, None, fx=scale, fy=scale) if scale != 1.0 else frame
        boxes, weights = self._hog.detectMultiScale(small, winStride=(8, 8), padding=(8, 8), scale=1.05)
        return [
            Detection("person", float(wt), (int(x / scale), int(y / scale), int(bw / scale), int(bh / scale)))
            for (x, y, bw, bh), wt in zip(boxes, np.ravel(weights))
            if wt > 0.5
        ]


class YoloDetector:
    """YOLOv8 (people, vehicles, animals and ~80 other things). Install with: pip install ultralytics"""

    name = "yolo"

    def __init__(self, model: str = "yolov8n.pt", min_confidence: float = 0.4) -> None:
        from ultralytics import YOLO  # imported here so it stays optional

        self._model = YOLO(model)  # downloads the model the first time
        self._min = min_confidence

    def detect(self, frame: np.ndarray) -> list[Detection]:
        result = self._model(frame, verbose=False)[0]
        out = []
        for box in result.boxes:
            conf = float(box.conf[0])
            if conf < self._min:
                continue
            x1, y1, x2, y2 = (int(v) for v in box.xyxy[0])
            out.append(Detection(result.names[int(box.cls[0])], conf, (x1, y1, x2 - x1, y2 - y1)))
        return out


def make_detector(kind: str = "auto"):
    """kind: auto (YOLO if installed, else HOG), yolo, hog, or none (movement only)."""
    if kind == "none":
        return None
    if kind in ("auto", "yolo"):
        try:
            return YoloDetector()
        except Exception as exc:  # not installed, or model could not be loaded
            if kind == "yolo":
                raise RuntimeError(f"YOLO is not available: {exc}") from exc
    return HogPersonDetector()
