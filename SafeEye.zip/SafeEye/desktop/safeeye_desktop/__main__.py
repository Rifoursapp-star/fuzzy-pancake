"""Command line: python -m safeeye_desktop <command>"""

from __future__ import annotations

import argparse
import sys
import threading
import time
from datetime import datetime

from . import __version__, config as cfgmod
from .alerts import Alarm
from .detector import make_detector
from .monitor import CameraWorker
from .sos import send_sos
from .store import AlertStore


def parse_hours(text: str) -> tuple[int, int]:
    start, _, end = text.partition("-")
    s, e = int(start), int(end)
    if not (0 <= s <= 23 and 0 <= e <= 23):
        raise ValueError("hours must be between 0 and 23")
    return s, e


def cmd_add_camera(args) -> int:
    cfg = cfgmod.load()
    if any(c.name == args.name for c in cfg.cameras):
        print(f"A camera named '{args.name}' already exists. Remove it first.")
        return 1
    start, end = parse_hours(args.hours)
    cfg.cameras.append(cfgmod.CameraConfig(
        name=args.name, source=args.source, sensitivity=args.sensitivity,
        clips=not args.no_clips, people_only=args.people_only, start_hour=start, end_hour=end,
    ))
    cfgmod.save(cfg)
    print(f"Added camera '{args.name}'.")
    return 0


def cmd_remove_camera(args) -> int:
    cfg = cfgmod.load()
    before = len(cfg.cameras)
    cfg.cameras = [c for c in cfg.cameras if c.name != args.name]
    cfgmod.save(cfg)
    print("Removed." if len(cfg.cameras) < before else "No camera with that name.")
    return 0


def cmd_list(_args) -> int:
    cfg = cfgmod.load()
    if not cfg.cameras:
        print("No cameras yet. Add one:  python -m safeeye_desktop add-camera Webcam 0")
    for c in cfg.cameras:
        hours = "always" if c.start_hour == c.end_hour else f"{c.start_hour:02d}:00-{c.end_hour:02d}:00"
        extra = " refours-cam" + (" siren-on-alert" if c.siren_on_alert else "") if c.refours_api else ""
        print(f"{c.name:15} {cfgmod.mask_url(c.source)}  sensitivity={c.sensitivity} clips={c.clips} "
              f"people_only={c.people_only} hours={hours}{extra}")
    return 0


def cmd_discover(_args) -> int:
    from .refours import RefoursError, discover

    try:
        cams = discover()
    except RefoursError as exc:
        print(exc)
        return 1
    if not cams:
        print("No Refours Cams found. Check they are powered and on the same Wi-Fi, "
              "or pair by address:  run pair <address> --code <code>")
        return 1
    for c in cams:
        print(f"{c['name']}  id {c['id']}  address {c['host']}")
        print(f"    pair it:  run pair {c['host']} --code <pairing code> --api-port {c['api_port']}")
    return 0


def cmd_ptz(args) -> int:
    from .refours import RefoursClient, RefoursError

    cam = next((c for c in cfgmod.load().cameras if c.name == args.camera), None)
    if cam is None or not cam.refours_api:
        print(f"'{args.camera}' is not a paired Refours Cam. See: list")
        return 1
    client = RefoursClient(cam.refours_api, cam.refours_code)
    try:
        if args.home:
            state = client.ptz_home()
        elif args.patrol:
            state = client.ptz_patrol(args.patrol == "on")
        elif args.pan is not None or args.tilt is not None:
            state = client.ptz_to(*([args.pan, args.tilt] if None not in (args.pan, args.tilt) else
                                    [args.pan if args.pan is not None else client.ptz_status()["pan"],
                                     args.tilt if args.tilt is not None else client.ptz_status()["tilt"]]))
        else:
            state = client.ptz_status()
    except RefoursError as exc:
        print(f"Error: {exc}")
        return 1
    print(f"pan {state['pan']}  tilt {state['tilt']}  moving={state['moving']}  patrol={state['patrol']}  "
          f"limits pan {state['limits']['pan']} tilt {state['limits']['tilt']}")
    return 0


def cmd_pair(args) -> int:
    from .refours import RefoursClient, RefoursError

    api = f"http://{args.host}:{args.api_port}"
    client = RefoursClient(api, args.code)
    try:
        info = client.info()
        if info.get("model") != "Refours Cam":
            print("That device is not a Refours Cam.")
            return 1
        client.status()  # fails with "wrong pairing code" if the code is wrong
    except RefoursError as exc:
        print(f"Could not pair: {exc}")
        return 1
    cfg = cfgmod.load()
    name = args.name or info.get("name", "Refours Cam")
    if any(c.name == name for c in cfg.cameras):
        print(f"A camera named '{name}' already exists. Use --name to pick another name.")
        return 1
    if args.auto_track and not info.get("ptz"):
        print("This camera has no pan/tilt mount (set \"ptz_enabled\": true on the camera), so auto-track cannot be used.")
        return 1
    source = f"rtsp://refours:{args.code}@{args.host}:{info.get('rtsp_port', 8554)}/{info.get('rtsp_path', 'stream')}"
    cfg.cameras.append(cfgmod.CameraConfig(
        name=name, source=source, sensitivity=args.sensitivity, people_only=args.people_only,
        refours_api=api, refours_code=args.code, siren_on_alert=args.siren_on_alert,
        auto_track=args.auto_track, hfov_deg=float(info.get("hfov_deg", 0)), vfov_deg=float(info.get("vfov_deg", 0)),
    ))
    cfgmod.save(cfg)
    print(f"Paired with '{name}'. SafeEye will watch its video and listen for its SOS button.")
    return 0


def cmd_history(args) -> int:
    store = AlertStore(cfgmod.home_dir())
    events = store.list(args.n)
    if not events:
        print("No alerts yet.")
    for e in events:
        when = datetime.fromtimestamp(e["id"] / 1000).strftime("%Y-%m-%d %H:%M:%S")
        files = " ".join(str(store.dir / e[k]) for k in ("snapshot", "clip") if e.get(k))
        print(f"{when}  [{e['camera']}] {e['reason']}\n    {files}")
    return 0


def cmd_sos(args) -> int:
    cfg = cfgmod.load()
    results = send_sos(cfg.sos, args.reason, open_whatsapp=args.whatsapp)
    for channel, ok, detail in results:
        print(f"{'OK  ' if ok else 'FAIL'} {channel}: {detail}")
    return 0 if any(ok for _, ok, _ in results) else 1


def cmd_test_alarm(_args) -> int:
    Alarm(cfgmod.home_dir(), cooldown=0).sound("SafeEye", "Test alarm")
    time.sleep(2.5)
    return 0


def cmd_run(args) -> int:
    cfg = cfgmod.load()
    if not cfg.cameras:
        print("No cameras yet. Add one:  python -m safeeye_desktop add-camera Webcam 0")
        return 1
    home = cfgmod.home_dir()
    store, alarm = AlertStore(home), Alarm(home)
    try:
        detector = make_detector(args.detector)
    except RuntimeError as exc:
        print(exc)
        return 1
    print(f"SafeEye {__version__} watching {len(cfg.cameras)} camera(s) with "
          f"{getattr(detector, 'name', 'movement only')} detection. Press Ctrl+C to stop.")

    from .refours import RefoursClient, RefoursWatcher

    clients = {c.name: RefoursClient(c.refours_api, c.refours_code) for c in cfg.cameras if c.refours_api}

    def sound_camera_siren(cam, _reason: str) -> None:
        client = clients.get(cam.name)
        if client and cam.siren_on_alert:
            threading.Thread(target=_safe_siren, args=(client,), daemon=True).start()

    from .tracking import Tracker

    trackers = {
        c.name: Tracker(clients[c.name], c.hfov_deg, c.vfov_deg, home_after=c.track_home_after)
        for c in cfg.cameras
        if c.auto_track and c.name in clients and c.hfov_deg > 0 and c.vfov_deg > 0
    }
    for c in cfg.cameras:
        if c.auto_track and c.name not in trackers:
            print(f"[{c.name}] auto-track is on but needs a paired Refours Cam with pan/tilt: re-run pair")

    workers = [CameraWorker(c, store, alarm, detector, on_alert=sound_camera_siren, tracker=trackers.get(c.name))
               for c in cfg.cameras]
    for w in workers:
        w.start()

    last_sos = [0.0]

    def danger(reason: str, urgent: bool = False, source: str = "Microphone") -> None:
        print(f"DANGER: {reason}")
        alarm.sound("SafeEye", reason)
        store.add(source, reason, _blank())
        # Automatic SOS: once per 5 minutes. A panic button is urgent: once per 30 seconds.
        if time.monotonic() - last_sos[0] > (30 if urgent else 300):
            last_sos[0] = time.monotonic()
            for channel, ok, detail in send_sos(cfg.sos, reason):
                print(f"  SOS {channel}: {'sent' if ok else 'failed'} ({detail})")

    watchers = [
        RefoursWatcher(name, client, lambda why, n=name: danger(why, urgent=True, source=n))
        for name, client in clients.items()
    ]
    for watcher in watchers:
        watcher.start()

    captions = None
    if args.captions:
        try:
            from .captions import CaptionListener

            captions = CaptionListener(
                cfg.sos.danger_words,
                on_caption=lambda t: print(f"CAPTION: {t}"),
                on_danger=lambda w: danger(f'Heard "{w}"'),
                on_loud=lambda: danger("Loud sound heard"),
            )
            captions.start()
        except ImportError:
            print("Captions need:  pip install SpeechRecognition PyAudio")

    try:
        if args.show:
            _preview(workers)
        else:
            while any(not w.done.is_set() for w in workers):
                time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        for w in workers:
            w.stop()
        for watcher in watchers:
            watcher.stop()
        if captions:
            captions.stop()
        for w in workers:
            w.join(timeout=5)
    print("Stopped.")
    return 0


def _safe_siren(client) -> None:
    try:
        client.siren(True, 10)
    except Exception:
        pass  # the camera may be unreachable; SafeEye's own alarm already sounded


def _blank():
    import numpy as np

    return np.zeros((90, 160, 3), dtype=np.uint8)


def _preview(workers) -> None:
    """Shows each camera with boxes drawn on it. Press q in a window to quit."""
    import cv2

    while any(not w.done.is_set() for w in workers):
        for w in workers:
            if w.latest is None:
                continue
            frame, detections, motion = w.latest
            view = frame.copy()
            for d in detections:
                x, y, bw, bh = d.box
                cv2.rectangle(view, (x, y), (x + bw, y + bh), (0, 255, 0), 2)
                cv2.putText(view, d.label, (x, max(15, y - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.putText(view, f"{w.cam.name}: {w.status}{'  MOTION' if motion else ''}", (10, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.imshow(f"SafeEye - {w.cam.name}", view)
        if cv2.waitKey(50) & 0xFF == ord("q"):
            break
    cv2.destroyAllWindows()


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="safeeye", description="SafeEye by Refours Systems (desktop)")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    a = sub.add_parser("add-camera", help="add a webcam (0), IP camera (rtsp://...) or video file")
    a.add_argument("name")
    a.add_argument("source")
    a.add_argument("--sensitivity", choices=["low", "medium", "high"], default="medium")
    a.add_argument("--no-clips", action="store_true", help="save a snapshot only, no video clip")
    a.add_argument("--people-only", action="store_true", help="alert only when a person is detected")
    a.add_argument("--hours", default="0-0", help="watch only between hours, e.g. 20-6 (default: always)")
    a.set_defaults(func=cmd_add_camera)

    r = sub.add_parser("remove-camera")
    r.add_argument("name")
    r.set_defaults(func=cmd_remove_camera)

    sub.add_parser("list", help="show saved cameras").set_defaults(func=cmd_list)
    sub.add_parser("discover", help="find Refours Cams on the network").set_defaults(func=cmd_discover)

    pr = sub.add_parser("pair", help="add a Refours Cam by its address and pairing code")
    pr.add_argument("host", help="the camera's address, e.g. 192.168.1.50")
    pr.add_argument("--code", required=True, help="the pairing code shown by the camera")
    pr.add_argument("--name", help="a name for it (default: the camera's own name)")
    pr.add_argument("--api-port", type=int, default=8080)
    pr.add_argument("--sensitivity", choices=["low", "medium", "high"], default="medium")
    pr.add_argument("--people-only", action="store_true")
    pr.add_argument("--siren-on-alert", action="store_true", help="sound the camera's siren when movement is seen")
    pr.add_argument("--auto-track", action="store_true", help="turn the camera's pan/tilt mount to follow movement")
    pr.set_defaults(func=cmd_pair)

    pz = sub.add_parser("ptz", help="aim a Refours Cam's pan/tilt mount by hand")
    pz.add_argument("camera", help="the camera's name (see: list)")
    pz.add_argument("--pan", type=float, help="angle in degrees; + is right")
    pz.add_argument("--tilt", type=float, help="angle in degrees; + is up")
    pz.add_argument("--home", action="store_true", help="go back to the centre view")
    pz.add_argument("--patrol", choices=["on", "off"], help="sweep between the camera's patrol points")
    pz.set_defaults(func=cmd_ptz)

    h = sub.add_parser("history", help="show recent alerts")
    h.add_argument("-n", type=int, default=20)
    h.set_defaults(func=cmd_history)

    s = sub.add_parser("sos", help="send an SOS now")
    s.add_argument("reason", nargs="?", default="Manual SOS")
    s.add_argument("--whatsapp", action="store_true", help="also open WhatsApp with the message ready")
    s.set_defaults(func=cmd_sos)

    sub.add_parser("test-alarm", help="play the siren").set_defaults(func=cmd_test_alarm)

    run = sub.add_parser("run", help="start watching all cameras")
    run.add_argument("--detector", choices=["auto", "yolo", "hog", "none"], default="auto")
    run.add_argument("--show", action="store_true", help="show live preview windows")
    run.add_argument("--captions", action="store_true", help="live captions + danger words (sends audio to Google)")
    run.set_defaults(func=cmd_run)

    args = p.parse_args(argv)
    try:
        return args.func(args)
    except ValueError as exc:
        print(f"Error: {exc}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
