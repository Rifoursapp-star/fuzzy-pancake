"""Refours Cam support: find cameras on the network, pair with one, listen for its SOS button,
and sound its siren."""

from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from typing import Callable

SERVICE_TYPE = "_refourscam._tcp.local."


class RefoursError(Exception):
    pass


class RefoursClient:
    def __init__(self, base_url: str, code: str = "", timeout: float = 10.0, urlopen=urllib.request.urlopen):
        self.base = base_url.rstrip("/")
        self.code = code
        self.timeout = timeout
        self._urlopen = urlopen

    def _request(self, path: str, method="GET", body: dict | None = None, timeout: float | None = None,
                 auth=True) -> bytes:
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method)
        if auth:
            req.add_header("Authorization", f"Bearer {self.code}")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with self._urlopen(req, timeout=timeout or self.timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                raise RefoursError("wrong pairing code") from exc
            if exc.code == 429:
                raise RefoursError("too many wrong codes: wait a minute and try again") from exc
            raise RefoursError(f"camera answered {exc.code}") from exc
        except (urllib.error.URLError, OSError) as exc:
            raise RefoursError(f"cannot reach the camera ({getattr(exc, 'reason', exc)})") from exc

    def _json(self, *a, **k) -> dict:
        try:
            return json.loads(self._request(*a, **k))
        except ValueError as exc:
            raise RefoursError("the camera sent an unreadable answer") from exc

    def info(self) -> dict:
        return self._json("/api/info", auth=False)

    def status(self) -> dict:
        return self._json("/api/status")

    def events(self, since: int, wait: float = 0.0) -> dict:
        return self._json(f"/api/events?since={int(since)}&wait={wait}", timeout=wait + self.timeout)

    def siren(self, on: bool, seconds: float = 10) -> dict:
        return self._json("/api/siren", "POST", {"on": on, "seconds": seconds})

    def ptz_status(self) -> dict:
        return self._json("/api/ptz")

    def ptz_move(self, dpan: float, dtilt: float) -> dict:
        """Turn by an amount. + pan is right, + tilt is up."""
        return self._json("/api/ptz", "POST", {"dpan": dpan, "dtilt": dtilt})

    def ptz_to(self, pan: float, tilt: float) -> dict:
        return self._json("/api/ptz", "POST", {"pan": pan, "tilt": tilt})

    def ptz_home(self) -> dict:
        return self._json("/api/ptz", "POST", {"home": True})

    def ptz_patrol(self, on: bool) -> dict:
        return self._json("/api/ptz", "POST", {"patrol": on})

    def snapshot(self) -> bytes:
        return self._request("/api/snapshot", timeout=20)


class RefoursWatcher(threading.Thread):
    """Waits for events from one camera and reports its SOS button."""

    def __init__(self, name: str, client: RefoursClient, on_sos: Callable[[str], None],
                 log: Callable[[str], None] = print, wait: float = 20.0, retry: float = 5.0):
        super().__init__(daemon=True, name=f"safeeye-refours-{name}")
        self.camera, self.client, self.on_sos, self.log = name, client, on_sos, log
        self.wait, self.retry = wait, retry
        self.stop_event = threading.Event()
        self.connected = False

    def run(self) -> None:
        since = None
        while not self.stop_event.is_set():
            try:
                if since is None:  # only react to things that happen from now on
                    since = int(self.client.status()["last_event_id"])
                    self.connected = True
                    self.log(f"[{self.camera}] Refours Cam connected")
                reply = self.client.events(since, self.wait)
                last = int(reply.get("last_id", since))
                if last < since:  # the camera restarted and began counting again
                    since = last
                    continue
                for event in reply.get("events", []):
                    since = max(since, int(event["id"]))
                    if event.get("kind") == "sos_button":
                        self.on_sos(f"SOS button pressed on {self.camera}")
            except (RefoursError, KeyError, ValueError, TypeError) as exc:
                if self.connected:
                    self.log(f"[{self.camera}] camera link lost: {exc}")
                self.connected = False
                since = None
                self.stop_event.wait(self.retry)

    def stop(self) -> None:
        self.stop_event.set()


def parse_service(addresses: list[str], port: int, properties: dict) -> dict | None:
    """Turns an mDNS announcement into a plain dict. None if it is not a Refours Cam."""
    props = {
        (k.decode() if isinstance(k, bytes) else k): (v.decode() if isinstance(v, bytes) else v)
        for k, v in properties.items()
    }
    if props.get("model") != "Refours Cam" or not addresses:
        return None
    try:
        return {
            "id": props.get("id", ""), "name": props.get("name", "Refours Cam"), "host": addresses[0],
            "api_port": int(props.get("api_port", port)), "rtsp_port": int(props.get("rtsp_port", 8554)),
            "path": props.get("path", "stream"),
        }
    except ValueError:
        return None


def discover(timeout: float = 4.0) -> list[dict]:
    """Finds Refours Cams on the local network. Needs: pip install zeroconf"""
    try:
        from zeroconf import ServiceBrowser, Zeroconf
    except ImportError as exc:
        raise RefoursError("discovery needs:  pip install zeroconf   (or pair by address: run pair <address> --code <code>)") from exc
    found: dict[str, dict] = {}

    class Listener:
        def add_service(self, zc, type_, name):
            info = zc.get_service_info(type_, name, timeout=2000)
            if info:
                cam = parse_service(info.parsed_addresses(), info.port, info.properties)
                if cam:
                    found[cam["id"] or name] = cam

        def update_service(self, zc, type_, name):
            self.add_service(zc, type_, name)

        def remove_service(self, zc, type_, name):
            pass

    zc = Zeroconf()
    try:
        ServiceBrowser(zc, SERVICE_TYPE, Listener())
        threading.Event().wait(timeout)
    finally:
        zc.close()
    return list(found.values())
