"""Watches one camera: movement detection, optional person detection, alerts and clips."""

from __future__ import annotations

import os
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from typing import Callable

import cv2

from .alerts import Alarm
from .config import CameraConfig, mask_url
from .detector import Detection, MotionDetector
from .store import AlertStore

# RTSP over TCP is more reliable on Wi-Fi and the internet.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")


def shrink(frame, max_width: int = 960):
    h, w = frame.shape[:2]
    if w <= max_width:
        return frame
    return cv2.resize(frame, (max_width, int(h * max_width / w)), interpolation=cv2.INTER_AREA)


def frames_from(cam: CameraConfig, stop: threading.Event):
    """Yields (frame, timestamp). Files use video time so they replay as fast as possible."""
    if sys.platform == "win32" and cam.source.isdigit():
        cap = cv2.VideoCapture(cam.capture_source(), cv2.CAP_DSHOW)
    else:
        cap = cv2.VideoCapture(cam.capture_source())
    if not cap.isOpened():
        cap.release()
        raise ConnectionError(f"Cannot open camera '{cam.name}' ({mask_url(cam.source)})")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    index = 0
    try:
        while not stop.is_set():
            ok, frame = cap.read()
            if not ok:
                return
            yield frame, (index / fps if cam.is_file else time.monotonic())
            index += 1
    finally:
        cap.release()


@dataclass
class _Clip:
    event_id: int
    frames: list
    times: list
    end: float


class CameraWorker(threading.Thread):
    ANALYZE_FPS = 10      # frames examined per second
    PRE_ROLL = 3.0        # seconds of video kept from before the alert
    POST_ROLL = 8.0       # seconds recorded after the alert
    COOLDOWN = 15.0       # minimum seconds between alerts from one camera
    RETRY_SECONDS = 10    # wait before reconnecting a dropped stream

    def __init__(
        self,
        cam: CameraConfig,
        store: AlertStore,
        alarm: Alarm,
        detector=None,
        hour_fn: Callable[[], int] | None = None,
        log: Callable[[str], None] = print,
        on_alert: Callable[[CameraConfig, str], None] | None = None,
        tracker=None,
    ):
        super().__init__(daemon=True, name=f"safeeye-{cam.name}")
        self.cam = cam
        self.tracker = tracker
        self.on_alert = on_alert
        self.store = store
        self.alarm = alarm
        self.detector = detector
        self.hour_fn = hour_fn or (lambda: datetime.now().hour)
        self.log = log
        self.stop_event = threading.Event()
        self.done = threading.Event()
        self.alerts_raised = 0
        self.latest = None  # (frame, detections, motion) for the preview window
        self.status = "starting"
        self._motion = MotionDetector(cam.threshold)
        self._preroll: deque = deque()
        self._clip: _Clip | None = None
        self._last_ts = float("-inf")
        self._last_alert = float("-inf")

    # -- thread ------------------------------------------------------------

    def run(self) -> None:
        try:
            while not self.stop_event.is_set():
                try:
                    self.status = "watching"
                    for frame, ts in frames_from(self.cam, self.stop_event):
                        self.process(frame, ts)
                except ConnectionError as exc:
                    self.log(f"[{self.cam.name}] {exc}")
                if self.cam.is_file:
                    break
                self.status = f"reconnecting in {self.RETRY_SECONDS}s"
                self._finish_clip()
                self.stop_event.wait(self.RETRY_SECONDS)
        finally:
            self._finish_clip()
            self.status = "stopped"
            self.done.set()

    def stop(self) -> None:
        self.stop_event.set()

    # -- core logic (also called directly by tests) ------------------------

    def process(self, frame, ts: float) -> None:
        if ts - self._last_ts < 1.0 / self.ANALYZE_FPS:
            return
        self._last_ts = ts

        if not self.cam.active_at(self.hour_fn()):  # outside this camera's schedule
            self._motion.reset()
            self._preroll.clear()
            self._finish_clip()
            self.status = "off schedule"
            return
        self.status = "watching"

        small = shrink(frame)
        if self._clip is not None:
            self._clip.frames.append(small)
            self._clip.times.append(ts)
            if ts >= self._clip.end:
                self._finish_clip()
        else:
            self._preroll.append((ts, small))
            while self._preroll and ts - self._preroll[0][0] > self.PRE_ROLL:
                self._preroll.popleft()

        if self.tracker:
            self.tracker.idle(ts)
            if self.tracker.settling(ts):
                # The camera is turning, so the whole picture shifts. That is not movement.
                self._motion.reset()
                self.status = "camera turning"
                return

        motion = self._motion.update(small)
        if motion and self.tracker and self._motion.centroid:
            self.tracker.update(*self._motion.centroid, ts)
        self.latest = (small, [], motion)
        if not motion or ts - self._last_alert < self.COOLDOWN:
            return

        detections = self.detector.detect(small) if self.detector else []
        self.latest = (small, detections, motion)
        if self.cam.people_only and not any(d.label == "person" for d in detections):
            return
        self._raise(small, ts, detections)

    def _raise(self, small, ts: float, detections: list[Detection]) -> None:
        self._last_alert = ts
        self.alerts_raised += 1
        reason = f"Movement: {_summarize(detections)}" if detections else "Movement detected"
        event_id = self.store.add(self.cam.name, reason, small)
        self.alarm.sound(f"SafeEye: {self.cam.name}", reason)
        self.log(f"ALERT [{self.cam.name}] {reason}")
        if self.on_alert:
            try:
                self.on_alert(self.cam, reason)
            except Exception as exc:  # a failing hook must never stop the watching
                self.log(f"[{self.cam.name}] alert hook failed: {type(exc).__name__}")
        if self.cam.clips:
            frames = [f for _, f in self._preroll]
            times = [t for t, _ in self._preroll]
            self._preroll.clear()
            self._clip = _Clip(event_id, frames, times, ts + self.POST_ROLL)

    def _finish_clip(self) -> None:
        clip, self._clip = self._clip, None
        if clip and clip.frames:
            # Play back at the speed it was recorded, whatever the camera's frame rate.
            span = clip.times[-1] - clip.times[0] if len(clip.times) > 1 else 0
            fps = (len(clip.times) - 1) / span if span > 0 else self.ANALYZE_FPS
            self.store.attach_clip(clip.event_id, clip.frames, min(max(fps, 1.0), 30.0))


def _summarize(detections: list[Detection]) -> str:
    counts: dict[str, int] = {}
    for d in detections:
        counts[d.label] = counts.get(d.label, 0) + 1
    return ", ".join(f"{n} {label}" for label, n in counts.items())
