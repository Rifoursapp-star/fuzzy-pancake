"""Settings: cameras (each with its own options) and SOS contacts, saved as JSON."""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path

SENSITIVITY = {"low": 0.08, "medium": 0.03, "high": 0.012}


def mask_url(text: str) -> str:
    """Hides the password in addresses like rtsp://user:PASSWORD@host so it never reaches the screen or logs."""
    return re.sub(r"(://[^/\s:@]+:)[^@\s/]+@", r"\1***@", text)


def home_dir() -> Path:
    """Where SafeEye keeps its settings and alert history (override with SAFEEYE_HOME)."""
    path = Path(os.environ.get("SAFEEYE_HOME") or Path.home() / ".safeeye")
    path.mkdir(parents=True, exist_ok=True)
    return path


@dataclass
class CameraConfig:
    name: str
    # "0" = first webcam, an rtsp:// address for an IP camera, or a video file path.
    source: str
    sensitivity: str = "medium"      # low | medium | high
    clips: bool = True               # save a short MP4 with each alert
    people_only: bool = False        # alert only when a person is detected
    start_hour: int = 0              # watch only between these hours (0-23)
    end_hour: int = 0                # same start and end = always; 20 to 6 = overnight
    # Refours Cam extras (filled in by the `pair` command):
    refours_api: str = ""            # e.g. http://192.168.1.50:8080
    refours_code: str = ""           # the camera's pairing code
    siren_on_alert: bool = False     # sound the camera's own siren when SafeEye sees movement
    auto_track: bool = False         # turn the camera's pan/tilt mount to follow movement
    hfov_deg: float = 0.0            # the camera's field of view, learned when pairing
    vfov_deg: float = 0.0
    track_home_after: int = 60       # seconds without movement before returning to the home view

    @property
    def threshold(self) -> float:
        return SENSITIVITY.get(self.sensitivity, SENSITIVITY["medium"])

    def active_at(self, hour: int) -> bool:
        if self.start_hour == self.end_hour:
            return True
        if self.start_hour < self.end_hour:
            return self.start_hour <= hour < self.end_hour
        return hour >= self.start_hour or hour < self.end_hour

    @property
    def is_file(self) -> bool:
        return os.path.isfile(self.source)

    def capture_source(self):
        return int(self.source) if self.source.isdigit() else self.source


@dataclass
class SosConfig:
    # Phone numbers in international format, e.g. +254700000000 (used for WhatsApp links).
    whatsapp_numbers: list[str] = field(default_factory=list)
    # Telegram bot: create one with @BotFather; the token can also be set in SAFEEYE_TELEGRAM_TOKEN.
    telegram_token: str = ""
    telegram_chat_ids: list[str] = field(default_factory=list)
    # Email (SMTP). The password can also be set in SAFEEYE_SMTP_PASSWORD.
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    email_to: list[str] = field(default_factory=list)
    # Where this computer is, as "lat,lon" or an address. Desktops have no GPS.
    location: str = ""
    # If true and no location is set, ask a public IP-location service (city-level only).
    use_ip_location: bool = False
    danger_words: list[str] = field(
        default_factory=lambda: ["help", "fire", "thief", "stop", "gun", "msaada", "moto", "mwizi"]
    )


@dataclass
class Config:
    cameras: list[CameraConfig] = field(default_factory=list)
    sos: SosConfig = field(default_factory=SosConfig)


def config_path(home: Path | None = None) -> Path:
    return (home or home_dir()) / "config.json"


def load(home: Path | None = None) -> Config:
    path = config_path(home)
    if not path.exists():
        return Config()
    data = json.loads(path.read_text(encoding="utf-8"))
    known_cam = set(CameraConfig.__dataclass_fields__)
    known_sos = set(SosConfig.__dataclass_fields__)
    return Config(
        cameras=[
            CameraConfig(**{k: v for k, v in c.items() if k in known_cam})
            for c in data.get("cameras", [])
        ],
        sos=SosConfig(**{k: v for k, v in data.get("sos", {}).items() if k in known_sos}),
    )


def save(cfg: Config, home: Path | None = None) -> Path:
    path = config_path(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(cfg), indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)  # may hold a bot token or email password
    except OSError:
        pass
    return path
