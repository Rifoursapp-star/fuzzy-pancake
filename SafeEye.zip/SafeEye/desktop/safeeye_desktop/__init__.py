"""SafeEye by Refours Systems - desktop version (Windows, macOS, Linux)."""

__version__ = "1.0.0"
