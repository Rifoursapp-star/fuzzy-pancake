"""Auto-tracking: turns a Refours Cam's pan/tilt mount toward movement, in small look-and-adjust steps.

Why "step and look": when the camera turns, the whole picture shifts and looks like movement.
So after each turn SafeEye ignores the picture until the mount has stopped and settled."""

from __future__ import annotations

import threading
from typing import Callable

from .refours import RefoursError


class Tracker:
    def __init__(
        self,
        client,
        hfov_deg: float,
        vfov_deg: float,
        *,
        deadband: float = 2.0,       # degrees: smaller errors are ignored (stops jitter)
        gain: float = 0.7,           # turn this fraction of the error each step (avoids overshoot)
        max_step: float = 6.0,       # largest single turn, degrees
        speed_dps: float = 20.0,     # the mount's speed, to know how long a turn takes
        min_interval: float = 0.3,
        home_after: float = 60.0,    # seconds without movement before returning to the home view (0 = never)
        sync: bool = False,          # send commands in the same thread (tests)
        log: Callable[[str], None] = print,
    ):
        self.client, self.hfov, self.vfov = client, hfov_deg, vfov_deg
        self.deadband, self.gain, self.max_step = deadband, gain, max_step
        self.speed, self.min_interval, self.home_after = max(1.0, speed_dps), min_interval, home_after
        self.sync, self.log = sync, log
        self.commands = 0
        self._next_ok = float("-inf")
        self._settle_until = float("-inf")
        self._last_seen: float | None = None
        self._at_home = True
        self._busy = threading.Lock()

    def update(self, cx: float, cy: float, ts: float) -> bool:
        """The moving thing is at (cx, cy), each 0-1 across the picture. True if a turn was sent."""
        self._last_seen = ts
        self._at_home = False
        if ts < self._next_ok:
            return False
        err_pan = (cx - 0.5) * self.hfov          # right of centre -> pan right (+)
        err_tilt = -(cy - 0.5) * self.vfov        # below centre -> tilt down (-)
        dpan = _clamp(err_pan * self.gain, self.max_step) if abs(err_pan) >= self.deadband else 0.0
        dtilt = _clamp(err_tilt * self.gain, self.max_step) if abs(err_tilt) >= self.deadband else 0.0
        if dpan == 0.0 and dtilt == 0.0:
            return False
        self._next_ok = ts + self.min_interval
        self._settle_until = ts + max(abs(dpan), abs(dtilt)) / self.speed + 0.5
        self._send(lambda: self.client.ptz_move(dpan, dtilt))
        return True

    def settling(self, ts: float) -> bool:
        """True while the camera is turning or has only just stopped. Ignore the picture then."""
        return ts < self._settle_until

    def idle(self, ts: float) -> bool:
        """Call every frame. After a while with no movement, returns the camera to its home view."""
        if not self.home_after or self._at_home or self._last_seen is None:
            return False
        if ts - self._last_seen < self.home_after:
            return False
        self._at_home = True
        self._settle_until = ts + 6.0  # the way home can be a long turn
        self._send(self.client.ptz_home)
        return True

    def _send(self, action: Callable[[], object]) -> None:
        def run():
            if not self._busy.acquire(blocking=False):
                return  # still sending the last command: the next frame will correct
            try:
                action()
                self.commands += 1
            except RefoursError as exc:
                self.log(f"[tracking] camera did not answer: {exc}")
            finally:
                self._busy.release()

        if self.sync:
            run()
        else:
            threading.Thread(target=run, daemon=True).start()


def _clamp(value: float, limit: float) -> float:
    return max(-limit, min(limit, value))
