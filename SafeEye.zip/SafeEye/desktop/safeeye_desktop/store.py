"""Alert history on disk: snapshots, short MP4 clips and an append-only event log."""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import cv2


class AlertStore:
    MAX_EVENTS = 200

    def __init__(self, home: Path):
        self.dir = home / "alerts"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.index = self.dir / "events.jsonl"
        self._lock = threading.Lock()
        self._last_id = 0

    def add(self, camera: str, reason: str, snapshot) -> int:
        """Saves a snapshot and logs the alert immediately. Returns its id."""
        with self._lock:
            event_id = max(int(time.time() * 1000), self._last_id + 1)
            self._last_id = event_id
            name = f"{event_id}.jpg"
            cv2.imwrite(str(self.dir / name), snapshot, [cv2.IMWRITE_JPEG_QUALITY, 85])
            self._append({"id": event_id, "camera": camera, "reason": reason, "snapshot": name})
            self._prune()
            return event_id

    def attach_clip(self, event_id: int, frames: list, fps: float) -> str | None:
        """Writes the frames as an MP4 and links it to the alert. Returns the file name."""
        if not frames:
            return None
        name = f"{event_id}.mp4"
        path = self.dir / name
        height, width = frames[0].shape[:2]
        writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
        try:
            for frame in frames:
                if frame.shape[:2] != (height, width):
                    frame = cv2.resize(frame, (width, height))
                writer.write(frame)
        finally:
            writer.release()
        if not path.exists() or path.stat().st_size == 0:
            return None
        with self._lock:
            self._append({"id": event_id, "clip": name})
        return name

    def list(self, limit: int | None = None) -> list[dict]:
        """Newest first. Clip records are merged into their alert."""
        with self._lock:
            events = self._read()
        out = list(reversed(events.values()))
        return out[:limit] if limit else out

    def clear(self) -> None:
        with self._lock:
            for f in self.dir.iterdir():
                f.unlink(missing_ok=True)

    # -- internals ---------------------------------------------------------

    def _append(self, record: dict) -> None:
        with self.index.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")

    def _read(self) -> dict[int, dict]:
        events: dict[int, dict] = {}
        if not self.index.exists():
            return events
        for line in self.index.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            events.setdefault(rec["id"], {}).update(rec)
        return events

    def _prune(self) -> None:
        events = self._read()
        if len(events) <= self.MAX_EVENTS:
            return
        ids = list(events)
        for old in ids[: len(ids) - self.MAX_EVENTS]:
            for key in ("snapshot", "clip"):
                if events[old].get(key):
                    (self.dir / events[old][key]).unlink(missing_ok=True)
            del events[old]
        self.index.write_text(
            "".join(json.dumps(e) + "\n" for e in events.values()), encoding="utf-8"
        )
