"""Optional: live captions from the microphone, loud-sound and danger-word detection.

Needs:  pip install SpeechRecognition PyAudio numpy
PRIVACY: this uses Google's free web speech service, so the audio is sent to Google.
It is OFF unless you start SafeEye with --captions.
"""

from __future__ import annotations

import threading
from typing import Callable

import numpy as np


class CaptionListener(threading.Thread):
    LOUD_RMS = 6000  # loudness (16-bit samples) that counts as a loud sound

    def __init__(
        self,
        danger_words: list[str],
        on_caption: Callable[[str], None],
        on_danger: Callable[[str], None],
        on_loud: Callable[[], None],
    ):
        super().__init__(daemon=True, name="safeeye-captions")
        self.danger_words = [w.lower() for w in danger_words]
        self.on_caption, self.on_danger, self.on_loud = on_caption, on_danger, on_loud
        self.stop_event = threading.Event()

    def run(self) -> None:
        import speech_recognition as sr  # optional dependency

        recognizer = sr.Recognizer()
        with sr.Microphone() as mic:
            recognizer.adjust_for_ambient_noise(mic, duration=1)
            while not self.stop_event.is_set():
                try:
                    audio = recognizer.listen(mic, timeout=2, phrase_time_limit=6)
                except sr.WaitTimeoutError:
                    continue
                samples = np.frombuffer(audio.get_raw_data(convert_rate=16000, convert_width=2), dtype=np.int16)
                if samples.size and float(np.sqrt(np.mean(samples.astype(np.float64) ** 2))) > self.LOUD_RMS:
                    self.on_loud()
                try:
                    text = recognizer.recognize_google(audio)
                except (sr.UnknownValueError, sr.RequestError):
                    continue
                self.on_caption(text)
                lower = text.lower()
                hit = next((w for w in self.danger_words if w in lower), None)
                if hit:
                    self.on_danger(hit)

    def stop(self) -> None:
        self.stop_event.set()
