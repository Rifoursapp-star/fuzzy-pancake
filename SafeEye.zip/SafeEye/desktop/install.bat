@echo off
rem SafeEye desktop installer for Windows. Needs Python 3.9+ (python.org, tick "Add to PATH").
cd /d "%~dp0"
python -m venv .venv || goto :error
.venv\Scripts\python -m pip install --upgrade pip
.venv\Scripts\python -m pip install -r requirements.txt || goto :error
echo.
echo SafeEye is installed. Next:
echo   run.bat add-camera Webcam 0
echo   run.bat run --show
goto :eof
:error
echo Install failed. Check that Python 3.9 or newer is installed and on PATH.
exit /b 1
