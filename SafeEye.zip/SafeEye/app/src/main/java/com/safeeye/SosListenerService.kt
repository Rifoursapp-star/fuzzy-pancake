package com.safeeye

import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Receives the SOS sent from the watch and runs the normal SOS on the phone:
 * siren, then SMS with location to the trusted contacts.
 *
 * Tip: for the best location while the app is closed, turn on "Run in background".
 */
class SosListenerService : WearableListenerService() {

    override fun onMessageReceived(event: MessageEvent) {
        if (event.path != "/safeeye/sos") return

        val contacts = ContactsStore.load(this)
        if (contacts.isEmpty()) return

        AlertManager(this).alarm(cooldownMs = 0)
        SosManager(this).apply { this.contacts = contacts }
            .sendSos("SOS from my watch") { }
    }
}
