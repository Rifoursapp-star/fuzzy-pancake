package com.safeeye

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.safeeye.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var ui: ActivityMainBinding
    private lateinit var alerts: AlertManager
    private lateinit var sos: SosManager
    private lateinit var captions: CaptionEngine
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var goingBackground = false

    private val permissions: Array<String> = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)

        alerts = AlertManager(this)
        sos = SosManager(this)
        captions = CaptionEngine(
            context = this,
            onCaption = { text, _ -> runOnUiThread { ui.caption.text = text } },
            onLoudSound = { danger("Loud sound detected") },
            onDangerWord = { word -> danger("Heard \"$word\"") }
        )

        ui.sosButton.setOnClickListener { triggerSos("Manual SOS button pressed") }
        ui.contactsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        ui.backgroundButton.setOnClickListener { goBackground() }
        ui.ipCameraButton.setOnClickListener { startActivity(Intent(this, CamerasActivity::class.java)) }
        ui.historyButton.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }

        if (!allGranted()) ActivityCompat.requestPermissions(this, permissions, 10)
    }

    override fun onResume() {
        super.onResume()
        goingBackground = false
        sos.contacts = ContactsStore.load(this)
        if (!allGranted()) return
        // Coming back to the app: the screen takes over from the background service.
        if (MonitorService.running) MonitorService.stop(this)
        startAll()
    }

    override fun onPause() {
        super.onPause()
        if (!goingBackground) captions.stop()
    }

    private fun allGranted() = permissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (allGranted()) startAll()
        else Toast.makeText(this, "Camera, microphone, location and SMS permissions are needed", Toast.LENGTH_LONG).show()
    }

    private fun startAll() {
        startCamera()
        captions.start()
    }

    private fun goBackground() {
        if (!allGranted()) return
        if (ContactsStore.load(this).isEmpty()) {
            Toast.makeText(this, "Add at least one trusted contact first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        goingBackground = true
        captions.stop()
        ProcessCameraProvider.getInstance(this).get().unbindAll() // free the camera for the service
        MonitorService.start(this) // started while the app is visible, as Android requires
        Toast.makeText(this, "SafeEye keeps watching in the background", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(ui.preview.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, DetectionAnalyzer(onSnapshot = { jpeg, what ->
                        AlertLog.record(this, "Phone camera", "Movement: $what", jpeg)
                    }) { list, motion ->
                        ui.overlay.update(list, 480, 640)
                        runOnUiThread {
                            ui.status.text = "Objects: ${list.size}  Motion: ${if (motion) "YES" else "no"}"
                        }
                        if (motion && list.isNotEmpty()) danger("Movement detected in view")
                    })
                }

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun danger(reason: String) {
        if (alerts.alarm()) {
            runOnUiThread { ui.status.text = "ALERT: $reason" }
            // Movement alerts are saved with a snapshot by the analyzer; sounds are logged here.
            if (!reason.startsWith("Movement")) AlertLog.record(this, "Phone microphone", reason, null)
        }
    }

    private fun triggerSos(reason: String) {
        if (sos.contacts.isEmpty()) {
            Toast.makeText(this, "Add a trusted contact first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        alerts.alarm(cooldownMs = 0)
        sos.sendSos(reason) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() } }
    }

    override fun onDestroy() {
        super.onDestroy()
        captions.stop()
        alerts.release()
        cameraExecutor.shutdown()
    }
}
