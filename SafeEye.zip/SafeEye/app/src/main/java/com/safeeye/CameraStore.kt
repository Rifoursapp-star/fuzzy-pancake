package com.safeeye

import android.content.Context
import java.util.Calendar

/**
 * One saved IP / RTSP camera with its own settings.
 *
 * @param sensitivity 0 = low, 1 = medium, 2 = high (how much of the picture must change)
 * @param clips save a short clip (about 8 seconds) with each alert instead of one snapshot
 * @param startHour,endHour hours (0-23) when this camera is watched. Same value = always.
 *        Overnight works too: start 20, end 6 means 8 pm to 6 am.
 */
data class IpCamera(
    val name: String,
    val url: String,
    val sensitivity: Int = 1,
    val clips: Boolean = true,
    val startHour: Int = 0,
    val endHour: Int = 0
) {
    /** Fraction of the picture that must change to count as movement. */
    val motionThreshold: Double
        get() = when (sensitivity) { 0 -> 0.08; 2 -> 0.012; else -> 0.03 }

    fun activeAt(hour: Int): Boolean = when {
        startHour == endHour -> true
        startHour < endHour -> hour in startHour until endHour
        else -> hour >= startHour || hour < endHour
    }

    fun activeNow(): Boolean = activeAt(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
}

/** Saved list of IP / RTSP cameras. Stored privately on this phone. */
object CameraStore {
    private const val PREFS = "safeeye"
    private const val KEY = "ip_cameras"

    fun load(context: Context): MutableList<IpCamera> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "")!!
            .split("\n")
            .mapNotNull { line ->
                val p = line.split("\t")
                if (p.size < 2 || !p[1].startsWith("rtsp://")) null
                else IpCamera(
                    name = p[0],
                    url = p[1],
                    sensitivity = p.getOrNull(2)?.toIntOrNull()?.coerceIn(0, 2) ?: 1,
                    clips = p.getOrNull(3) != "0",
                    startHour = p.getOrNull(4)?.toIntOrNull()?.coerceIn(0, 23) ?: 0,
                    endHour = p.getOrNull(5)?.toIntOrNull()?.coerceIn(0, 23) ?: 0
                )
            }
            .toMutableList()

    fun save(context: Context, cameras: List<IpCamera>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, cameras.joinToString("\n") {
                listOf(
                    it.name.replace('\t', ' ').replace('\n', ' '), it.url, it.sensitivity,
                    if (it.clips) 1 else 0, it.startHour, it.endHour
                ).joinToString("\t")
            })
            .apply()
    }
}
