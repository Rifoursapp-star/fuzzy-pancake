package com.safeeye

import android.content.Context

/** Saves the trusted SOS contacts (international format, e.g. +254700000000). */
object ContactsStore {
    private const val PREFS = "safeeye"
    private const val KEY = "contacts"

    fun load(context: Context): List<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "")!!
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    fun save(context: Context, numbers: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, numbers.joinToString(",")).apply()
    }

    /** Accepts +254700000000 style numbers only (7 to 15 digits). */
    fun isValid(number: String) = Regex("^\\+[1-9][0-9]{6,14}$").matches(number)
}
