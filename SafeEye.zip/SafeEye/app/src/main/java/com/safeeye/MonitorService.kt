package com.safeeye

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.Executors

/**
 * Keeps SafeEye watching with the screen off or the app closed:
 * camera detection + motion, microphone captions/danger words, and alerts.
 * A persistent notification is required by Android and tells the user it is active.
 */
class MonitorService : LifecycleService() {

    private lateinit var alerts: AlertManager
    private lateinit var sos: SosManager
    private lateinit var captions: CaptionEngine
    private val executor = Executors.newSingleThreadExecutor()
    private var lastSos = 0L

    override fun onCreate() {
        super.onCreate()
        running = true
        alerts = AlertManager(this)
        sos = SosManager(this).apply { contacts = ContactsStore.load(this@MonitorService) }
        captions = CaptionEngine(
            context = this,
            onCaption = { _, _ -> },
            onLoudSound = { danger("Loud sound heard") },
            onDangerWord = { word -> danger("Heard \"$word\"", sendSos = true) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForegroundCompat()
        startCamera()
        captions.start()
        return START_STICKY
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(executor, DetectionAnalyzer(onSnapshot = { jpeg, what ->
                        AlertLog.record(this, "Phone camera (background)", "Movement: $what", jpeg)
                    }) { list, motion ->
                        // ML Kit's default labels are broad categories, not "person", so any
                        // detected object that moves counts.
                        if (motion && list.isNotEmpty()) danger("Movement detected in view", log = false)
                    })
                }
            future.get().unbindAll()
            future.get().bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun danger(reason: String, sendSos: Boolean = false, log: Boolean = true) {
        if (!alerts.alarm()) return
        notify("ALERT: $reason")
        if (log) AlertLog.record(this, "Phone microphone (background)", reason, null)
        // Auto-SOS at most once every 5 minutes so contacts are not flooded.
        val now = System.currentTimeMillis()
        if (sendSos && now - lastSos > 5 * 60_000) {
            lastSos = now
            sos.sendSos(reason) { }
        }
    }

    private fun startForegroundCompat() {
        val channelId = "safeeye_monitor"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "SafeEye monitoring", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel("safeeye_alert", "SafeEye alerts", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("SafeEye by Refours Systems is watching")
            .setContentText("Camera and microphone are active. Tap to open.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(
                1, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } else startForeground(1, notification)
    }

    private fun notify(text: String) {
        val n = NotificationCompat.Builder(this, "safeeye_alert")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("SafeEye by Refours Systems")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

    override fun onDestroy() {
        running = false
        captions.stop()
        alerts.release()
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        @Volatile var running = false

        fun start(context: Context) =
            ContextCompat.startForegroundService(context, Intent(context, MonitorService::class.java))

        fun stop(context: Context) =
            context.stopService(Intent(context, MonitorService::class.java))
    }
}
