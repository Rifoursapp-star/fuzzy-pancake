package com.safeeye

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlin.math.max

/**
 * Live captions from the microphone using Android's speech recognizer.
 * Restarts itself so captions keep flowing. Also reports loud sounds
 * (a possible scream, crash or alarm) so the app can raise a danger alert.
 */
class CaptionEngine(
    private val context: Context,
    private val onCaption: (text: String, isFinal: Boolean) -> Unit,
    private val onLoudSound: () -> Unit,
    private val onDangerWord: (word: String) -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false

    // Words that trigger an alert when heard (add local-language words as needed).
    private val dangerWords = listOf("help", "fire", "thief", "stop", "gun", "msaada", "moto", "mwizi")

    fun start() {
        if (running || !SpeechRecognizer.isRecognitionAvailable(context)) return
        running = true
        listen()
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
    }

    private fun listen() {
        if (!running) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                private var peak = 0f

                override fun onRmsChanged(rmsdB: Float) {
                    peak = max(peak, rmsdB)
                    if (rmsdB > 9.5f) onLoudSound()
                }

                override fun onPartialResults(partial: Bundle?) = deliver(partial, false)
                override fun onResults(results: Bundle?) {
                    deliver(results, true)
                    handler.postDelayed({ listen() }, 200)
                }

                override fun onError(error: Int) {
                    handler.postDelayed({ listen() }, 500)
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            startListening(intent)
        }
    }

    private fun deliver(bundle: Bundle?, final: Boolean) {
        val text = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        onCaption(text, final)
        val lower = text.lowercase()
        dangerWords.firstOrNull { lower.contains(it) }?.let(onDangerWord)
    }
}
