package com.safeeye

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.text.DateFormat
import java.util.Date

/**
 * Shows past alerts, newest first. Tap one to enlarge the snapshot or play its
 * clip (a short sequence of frames from just before and after the alert),
 * and share it to a contact through WhatsApp, email, etc.
 */
class HistoryActivity : AppCompatActivity() {

    private var events: List<AlertLog.Event> = emptyList()
    private lateinit var empty: TextView
    private lateinit var listView: ListView
    private val thumbs = LruCache<String, Bitmap>(60)
    private val dp by lazy { resources.displayMetrics.density }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = events.size
        override fun getItem(position: Int) = events[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@HistoryActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val p = (8 * dp).toInt()
                setPadding(p, p, p, p)
                addView(ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP },
                    LinearLayout.LayoutParams((88 * dp).toInt(), (66 * dp).toInt()))
                addView(TextView(context).apply { setPadding((12 * dp).toInt(), 0, 0, 0) },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            val e = events[position]
            val image = row.getChildAt(0) as ImageView
            val text = row.getChildAt(1) as TextView
            val clipNote = if (e.clip.isNotEmpty()) "  (clip)" else ""
            text.text = "${e.reason}$clipNote\n${e.source}\n${DateFormat.getDateTimeInstance().format(Date(e.time))}"
            val thumb = (e.image ?: e.clip.firstOrNull())?.let { thumbnail(it) }
            if (thumb != null) {
                image.setBackgroundColor(0)
                image.setImageBitmap(thumb)
            } else {
                image.setImageDrawable(null)
                image.setBackgroundColor(0xFF444444.toInt())
            }
            return row
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "Alert history"
            textSize = 24f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(this).apply {
            text = "Clear"
            setOnClickListener { confirmClear() }
        })
        root.addView(header)

        empty = TextView(this).apply {
            text = "No alerts yet. Snapshots and clips are saved on this phone only."
            setPadding(0, pad, 0, 0)
        }
        root.addView(empty)

        listView = ListView(this).apply {
            adapter = this@HistoryActivity.adapter
            setOnItemClickListener { _, _, position, _ -> showEvent(events[position]) }
        }
        root.addView(listView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        events = AlertLog.list(this)
        empty.visibility = if (events.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun thumbnail(name: String): Bitmap? {
        thumbs.get(name)?.let { return it }
        val bmp = decode(name, 8)
        if (bmp != null) thumbs.put(name, bmp)
        return bmp
    }

    private fun decode(name: String, sample: Int): Bitmap? {
        val file = AlertLog.imageFile(this, name)
        if (!file.exists()) return null
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun showEvent(e: AlertLog.Event) {
        val frames = if (e.clip.isNotEmpty()) e.clip else listOfNotNull(e.image)
        if (frames.isEmpty()) return

        val view = ImageView(this).apply { adjustViewBounds = true }
        val handler = Handler(Looper.getMainLooper())
        var index = 0
        val step = object : Runnable {
            override fun run() {
                decode(frames[index % frames.size], 2)?.let { view.setImageBitmap(it) }
                index++
                if (frames.size > 1) handler.postDelayed(this, 800) // plays like a short video
            }
        }
        step.run()

        val title = if (e.clip.isNotEmpty()) "${e.reason} (clip, ${e.clip.size} frames)" else e.reason
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Close", null)
            .setNeutralButton("Share") { _, _ -> share(e) }
            .create()
        dialog.setOnDismissListener { handler.removeCallbacks(step) }
        dialog.show()
    }

    /** Shares the snapshot with a text note. The user picks WhatsApp, SMS, email, etc. */
    private fun share(e: AlertLog.Event) {
        val name = e.image ?: e.clip.firstOrNull() ?: return
        val file = AlertLog.imageFile(this, name)
        if (!file.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val note = "SafeEye alert: ${e.reason} (${e.source}) at " +
            DateFormat.getDateTimeInstance().format(Date(e.time))
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, note)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share alert"))
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage("Delete all saved alerts, snapshots and clips from this phone?")
            .setPositiveButton("Delete") { _, _ ->
                AlertLog.clear(this)
                thumbs.evictAll()
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
