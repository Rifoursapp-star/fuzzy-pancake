package com.safeeye

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator

/** Local danger alarm: loud siren tone plus vibration. */
class AlertManager(context: Context) {

    private val vibrator = context.getSystemService(Vibrator::class.java)
    private val tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
    private var lastAlert = 0L

    /** Debounced so repeated detections do not spam the alarm. */
    fun alarm(cooldownMs: Long = 8000, durationMs: Int = 2500): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastAlert < cooldownMs) return false
        lastAlert = now
        tone.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, durationMs)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 800), -1))
        return true
    }

    fun release() = tone.release()
}
