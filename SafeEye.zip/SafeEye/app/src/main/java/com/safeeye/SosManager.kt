package com.safeeye

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.SmsManager
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

/**
 * "I'm lost / I need help": gets the current GPS location and sends it
 * to trusted contacts by SMS (works without internet) and WhatsApp.
 * Also gives a Google Maps link so anyone can navigate to the person.
 */
class SosManager(private val context: Context) {

    private val fused = LocationServices.getFusedLocationProviderClient(context)

    /** Phone numbers in international format, e.g. +254700000000 */
    var contacts: List<String> = emptyList()

    @SuppressLint("MissingPermission")
    fun sendSos(reason: String, onDone: (String) -> Unit) {
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc ->
                val where = if (loc != null)
                    "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
                else "location unavailable"
                val message = "SOS from SafeEye: $reason. I need help. My location: $where"

                contacts.forEach { sendSms(it, message) }
                openWhatsApp(contacts.firstOrNull(), message)
                onDone(message)
            }
            .addOnFailureListener { onDone("Could not get location") }
    }

    private fun sendSms(number: String, text: String) {
        try {
            val sms = context.getSystemService(SmsManager::class.java)
            sms.sendMultipartTextMessage(number, null, sms.divideMessage(text), null, null)
        } catch (_: Exception) { /* permission denied or no SIM */ }
    }

    private fun openWhatsApp(number: String?, text: String) {
        val digits = number?.filter { it.isDigit() } ?: return
        val uri = Uri.parse("https://wa.me/$digits?text=${Uri.encode(text)}")
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { /* blocked in background or WhatsApp missing: SMS was still sent */ }
    }

    /** Opens turn-by-turn walking directions to a safe place (e.g. a contact's location). */
    fun navigateTo(lat: Double, lng: Double) {
        val uri = Uri.parse("google.navigation:q=$lat,$lng&mode=w")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
