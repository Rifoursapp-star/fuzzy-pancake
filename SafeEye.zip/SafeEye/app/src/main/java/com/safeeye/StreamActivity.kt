package com.safeeye

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.safeeye.databinding.ActivityStreamBinding
import kotlin.math.abs

/**
 * Watches an IP / security / PTZ / long-range camera over RTSP and runs the same
 * AI detection and motion alerts on its video. This is how SafeEye reaches
 * beyond what a phone lens can see: connect a telephoto, PTZ or thermal camera
 * that exposes an RTSP address.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class StreamActivity : AppCompatActivity() {

    private lateinit var ui: ActivityStreamBinding
    private lateinit var alerts: AlertManager
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private val detector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
            .enableClassification()
            .enableMultipleObjects()
            .build()
    )

    private var busy = false
    private var previousLuma: IntArray? = null

    private val tick = object : Runnable {
        override fun run() {
            analyzeFrame()
            handler.postDelayed(this, 700)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityStreamBinding.inflate(layoutInflater)
        setContentView(ui.root)
        alerts = AlertManager(this)

        val prefs = getSharedPreferences("safeeye", MODE_PRIVATE)
        ui.urlInput.setText(prefs.getString("rtsp_url", ""))

        ui.connectButton.setOnClickListener {
            val url = ui.urlInput.text.toString().trim()
            if (!url.startsWith("rtsp://")) {
                ui.streamStatus.text = "Address must start with rtsp://"
                return@setOnClickListener
            }
            prefs.edit().putString("rtsp_url", url).apply()
            connect(url)
        }

        // Opened from the camera list: connect straight away.
        intent.getStringExtra("url")?.let {
            ui.urlInput.setText(it)
            connect(it)
        }
    }

    private fun connect(url: String) {
        player?.release()
        val exo = ExoPlayer.Builder(this).build()
        val source = RtspMediaSource.Factory()
            .setForceUseRtpTcp(true) // more reliable over Wi-Fi and the internet
            .createMediaSource(MediaItem.fromUri(url))
        exo.setMediaSource(source)
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) ui.streamStatus.text = "Connected. Watching..."
            }

            override fun onPlayerError(error: PlaybackException) {
                ui.streamStatus.text = "Could not connect: check the address, login and network"
            }
        })
        exo.prepare()
        exo.playWhenReady = true
        ui.playerView.player = exo
        player = exo
        ui.streamStatus.text = "Connecting..."

        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 1500)
    }

    private fun analyzeFrame() {
        if (busy) return
        val view = ui.playerView.videoSurfaceView as? TextureView ?: return
        if (!view.isAvailable) return
        val frame: Bitmap = view.getBitmap(640, 360) ?: return

        val motion = detectMotion(frame)
        busy = true
        detector.process(InputImage.fromBitmap(frame, 0))
            .addOnSuccessListener { objects ->
                val found = objects.map {
                    Detection(it.trackingId, it.labels.firstOrNull()?.text ?: "object", it.boundingBox)
                }
                ui.overlay.update(found, frame.width, frame.height)
                ui.streamStatus.text = "Objects: ${found.size}  Motion: ${if (motion) "YES" else "no"}"
                if (motion && found.isNotEmpty() && alerts.alarm()) {
                    ui.streamStatus.text = "ALERT: movement on IP camera"
                    AlertLog.record(this, "IP camera (live view)", "Movement detected", ImageUtil.bitmapToJpeg(frame))
                }
            }
            .addOnCompleteListener { busy = false }
    }

    /** Compares a tiny 32x18 grayscale version of consecutive frames. */
    private fun detectMotion(frame: Bitmap): Boolean {
        val small = Bitmap.createScaledBitmap(frame, 32, 18, false)
        val pixels = IntArray(32 * 18)
        small.getPixels(pixels, 0, 32, 0, 0, 32, 18)
        val luma = IntArray(pixels.size) {
            (Color.red(pixels[it]) * 3 + Color.green(pixels[it]) * 6 + Color.blue(pixels[it])) / 10
        }
        val prev = previousLuma
        previousLuma = luma
        if (prev == null) return false
        val changed = luma.indices.count { abs(luma[it] - prev[it]) > 25 }
        return changed.toDouble() / luma.size > 0.03
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(tick)
        player?.release()
        player = null
    }

    override fun onDestroy() {
        super.onDestroy()
        alerts.release()
    }
}
