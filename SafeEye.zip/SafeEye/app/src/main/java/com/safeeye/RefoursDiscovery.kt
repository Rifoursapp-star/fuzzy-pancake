package com.safeeye

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.net.HttpURLConnection
import java.net.URL

data class RefoursCam(
    val id: String,
    val name: String,
    val host: String,
    val apiPort: Int,
    val rtspPort: Int,
    val path: String
) {
    /** Video address SafeEye reads. The pairing code is the video password. */
    fun rtspUrl(code: String) = "rtsp://refours:$code@$host:$rtspPort/$path"
}

/** Finds Refours Cams on the same Wi-Fi (mDNS / Bonjour). The camera never announces its code. */
class RefoursDiscovery(
    context: Context,
    private val onFound: (RefoursCam) -> Unit
) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var running = false
    private val seen = mutableSetOf<String>()

    private val discoveryListener = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(info: NsdServiceInfo) {
            synchronized(queue) { queue.addLast(info) }
            resolveNext()
        }
        override fun onServiceLost(info: NsdServiceInfo) {}
        override fun onDiscoveryStarted(serviceType: String) {}
        override fun onDiscoveryStopped(serviceType: String) {}
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { running = false }
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
    }

    fun start() {
        if (running) return
        running = true
        nsd.discoverServices("_refourscam._tcp.", NsdManager.PROTOCOL_DNS_SD, discoveryListener)
    }

    fun stop() {
        if (!running) return
        running = false
        try { nsd.stopServiceDiscovery(discoveryListener) } catch (_: Exception) { }
    }

    // Android can only resolve one service at a time, so they wait in a queue.
    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val next: NsdServiceInfo
        synchronized(queue) {
            if (resolving || queue.isEmpty()) return
            resolving = true
            next = queue.removeFirst()
        }
        nsd.resolveService(next, object : NsdManager.ResolveListener {
            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = done()
            override fun onServiceResolved(info: NsdServiceInfo) {
                try {
                    fun txt(key: String) = info.attributes[key]?.toString(Charsets.UTF_8)
                    val host = info.host?.hostAddress
                    if (txt("model") == "Refours Cam" && host != null) {
                        val cam = RefoursCam(
                            id = txt("id") ?: host,
                            name = txt("name") ?: "Refours Cam",
                            host = host,
                            apiPort = txt("api_port")?.toIntOrNull() ?: info.port,
                            rtspPort = txt("rtsp_port")?.toIntOrNull() ?: 8554,
                            path = txt("path") ?: "stream"
                        )
                        if (seen.add(cam.id)) onFound(cam)
                    }
                } finally { done() }
            }
            private fun done() {
                synchronized(queue) { resolving = false }
                resolveNext()
            }
        })
    }

    companion object {
        /** Checks the pairing code against the camera. Call from a background thread. */
        fun codeIsValid(cam: RefoursCam, code: String): Boolean = try {
            val conn = URL("http://${cam.host}:${cam.apiPort}/api/status").openConnection() as HttpURLConnection
            conn.setRequestProperty("Authorization", "Bearer $code")
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            val ok = conn.responseCode == 200
            conn.disconnect()
            ok
        } catch (_: Exception) { false }
    }
}
