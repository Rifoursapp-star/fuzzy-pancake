package com.safeeye

import android.content.Context
import java.io.File

/**
 * Alert history stored only on this phone: a text index plus JPEG pictures.
 * An alert has one snapshot and, for cameras with clips turned on, a short clip
 * (a sequence of pictures about one second apart) attached a few seconds later.
 * Keeps the latest 200 events and deletes older pictures automatically.
 */
object AlertLog {

    data class Event(
        val id: Long,
        val time: Long,
        val source: String,
        val reason: String,
        val image: String?,
        val clip: List<String>
    )

    private const val MAX_EVENTS = 200
    private var lastId = 0L

    private fun dir(c: Context) = File(c.filesDir, "alerts").apply { mkdirs() }
    private fun index(c: Context) = File(dir(c), "events.tsv")

    fun imageFile(c: Context, name: String) = File(dir(c), name)

    /** Saves an alert with an optional snapshot. Returns its id (used to attach a clip later). */
    @Synchronized
    fun record(c: Context, source: String, reason: String, jpeg: ByteArray?): Long {
        val id = maxOf(System.currentTimeMillis(), lastId + 1)
        lastId = id
        val imageName = if (jpeg != null) "$id.jpg".also { imageFile(c, it).writeBytes(jpeg) } else "-"
        index(c).appendText("$id\t${clean(source)}\t${clean(reason)}\t$imageName\t-\n")
        prune(c)
        return id
    }

    /** Adds the clip pictures to an alert recorded earlier. Does nothing if it was already pruned. */
    @Synchronized
    fun attachClip(c: Context, id: Long, frames: List<ByteArray>) {
        if (frames.isEmpty()) return
        val file = index(c)
        if (!file.exists()) return
        val lines = file.readLines().toMutableList()
        val at = lines.indexOfFirst { it.startsWith("$id\t") }
        if (at < 0) return
        val names = frames.mapIndexed { i, bytes ->
            "$id-c$i.jpg".also { imageFile(c, it).writeBytes(bytes) }
        }
        val parts = lines[at].split("\t").toMutableList()
        while (parts.size < 5) parts.add("-")
        parts[4] = names.joinToString(",")
        lines[at] = parts.joinToString("\t")
        file.writeText(lines.joinToString("\n") + "\n")
    }

    /** Newest first. */
    @Synchronized
    fun list(c: Context): List<Event> {
        val file = index(c)
        if (!file.exists()) return emptyList()
        return file.readLines().mapNotNull { line ->
            val p = line.split("\t")
            if (p.size < 4) return@mapNotNull null
            val id = p[0].toLongOrNull() ?: return@mapNotNull null
            Event(
                id = id, time = id, source = p[1], reason = p[2],
                image = p[3].takeIf { it != "-" },
                clip = p.getOrNull(4)?.takeIf { it != "-" && it.isNotEmpty() }?.split(",") ?: emptyList()
            )
        }.reversed()
    }

    @Synchronized
    fun clear(c: Context) {
        dir(c).listFiles()?.forEach { it.delete() }
    }

    private fun prune(c: Context) {
        val lines = index(c).readLines()
        if (lines.size <= MAX_EVENTS) return
        val drop = lines.size - MAX_EVENTS
        lines.take(drop).forEach { line ->
            val p = line.split("\t")
            p.getOrNull(3)?.takeIf { it != "-" }?.let { imageFile(c, it).delete() }
            p.getOrNull(4)?.takeIf { it != "-" }?.split(",")?.forEach { imageFile(c, it).delete() }
        }
        index(c).writeText(lines.drop(drop).joinToString("\n") + "\n")
    }

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ')
}
