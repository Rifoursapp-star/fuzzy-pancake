package com.safeeye

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.ImageFormat
import android.media.Image
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Watches every saved IP/RTSP camera at the same time, with the screen off.
 * Each camera gets its own player and detector, reconnects by itself if the
 * stream drops, and on movement saves a snapshot to the alert history,
 * sounds the alarm and posts a notification.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class IpMonitorService : Service() {

    private lateinit var alerts: AlertManager
    private val main = Handler(Looper.getMainLooper())
    private val imageThread = HandlerThread("safeeye-ip-frames").apply { start() }
    private val imageHandler by lazy { Handler(imageThread.looper) }
    private val mlExecutor = Executors.newSingleThreadExecutor()
    private val workers = mutableListOf<CameraWorker>()

    override fun onCreate() {
        super.onCreate()
        running = true
        alerts = AlertManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val cameras = CameraStore.load(this)
        startForegroundCompat(cameras.size)
        workers.forEach { it.stop() }
        workers.clear()
        cameras.forEach { cam -> workers += CameraWorker(cam).also { it.start() } }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        workers.forEach { it.stop() }
        workers.clear()
        main.removeCallbacksAndMessages(null)
        alerts.release()
        mlExecutor.shutdown()
        imageThread.quitSafely()
        super.onDestroy()
    }

    private fun openHistory(): PendingIntent = PendingIntent.getActivity(
        this, 1, Intent(this, HistoryActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun startForegroundCompat(count: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("safeeye_monitor", "SafeEye monitoring", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel("safeeye_alert", "SafeEye alerts", NotificationManager.IMPORTANCE_HIGH)
        )
        val notification = NotificationCompat.Builder(this, "safeeye_monitor")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("SafeEye by Refours Systems")
            .setContentText("Watching $count IP camera(s). Tap to see alerts.")
            .setContentIntent(openHistory())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(3, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else startForeground(3, notification)
    }

    /** Saves the alert, sounds the alarm, notifies. Returns the event id for attaching a clip. */
    private fun raiseAlert(camera: String, description: String, jpeg: ByteArray?): Long {
        val eventId = AlertLog.record(this, camera, "Movement: $description", jpeg)
        alerts.alarm()
        val n = NotificationCompat.Builder(this, "safeeye_alert")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("ALERT: $camera")
            .setContentText("Movement: $description")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openHistory())
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify(1000 + (camera.hashCode() and 0xFF), n)
        return eventId
    }

    /** One IP camera: player, frame reader, detector and reconnect logic. */
    private inner class CameraWorker(private val cam: IpCamera) {
        private var player: ExoPlayer? = null
        private var reader: ImageReader? = null
        private var width = 0
        private var height = 0
        private var busy = false
        private var stopped = false
        private var lastRun = 0L
        private var lastAlert = 0L
        private var previous: ByteArray? = null

        // Clip: about 3 s before the alert and 8 s after, one frame per second.
        private val preRoll = ArrayDeque<ByteArray>()
        private var lastClipTick = 0L
        private var clipFrames: MutableList<ByteArray>? = null
        private var clipEventId = 0L
        private var clipEnd = 0L

        private val detector = ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
                .enableClassification()
                .enableMultipleObjects()
                .build()
        )

        fun start() {
            if (stopped) return
            val exo = ExoPlayer.Builder(this@IpMonitorService).build()
            exo.setMediaSource(
                RtspMediaSource.Factory()
                    .setForceUseRtpTcp(true)
                    .createMediaSource(MediaItem.fromUri(cam.url))
            )
            exo.addListener(object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    attachReader(videoSize.width, videoSize.height)
                }

                override fun onPlayerError(error: PlaybackException) {
                    reconnectLater()
                }
            })
            exo.prepare()
            exo.playWhenReady = true
            player = exo
            // Frames arrive once the stream reports its size (onVideoSizeChanged).
            width = 0; height = 0
        }

        fun stop() {
            stopped = true
            main.removeCallbacksAndMessages(null)
            flushClip()
            release()
            detector.close()
        }

        /** Saves a half-recorded clip (service stopped or stream dropped) instead of losing it. */
        @Synchronized
        private fun flushClip() {
            val clip = clipFrames ?: return
            clipFrames = null
            if (clip.isNotEmpty()) AlertLog.attachClip(this@IpMonitorService, clipEventId, clip.toList())
        }

        private fun release() {
            player?.release(); player = null
            reader?.close(); reader = null
        }

        private fun reconnectLater() {
            flushClip()
            release()
            if (stopped) return
            main.postDelayed({ start() }, 10_000) // try again in 10 seconds
        }

        private fun attachReader(w: Int, h: Int) {
            if (w <= 0 || h <= 0 || (w == width && h == height)) return
            width = w; height = h
            reader?.close()
            val r = ImageReader.newInstance(w, h, ImageFormat.YUV_420_888, 3)
            r.setOnImageAvailableListener({ onFrame(it) }, imageHandler)
            reader = r
            player?.setVideoSurface(r.surface)
        }

        private fun onFrame(rd: ImageReader) {
            val image = try { rd.acquireLatestImage() } catch (_: Exception) { null } ?: return
            val now = SystemClock.elapsedRealtime()
            // Outside this camera's schedule: do nothing (saves battery).
            if (!cam.activeNow()) {
                image.close(); return
            }
            captureClipFrame(image, now)
            if (busy || now - lastRun < 700) {
                image.close(); return
            }
            lastRun = now
            busy = true
            val motion = detectMotion(image)
            detector.process(InputImage.fromMediaImage(image, 0))
                .addOnSuccessListener(mlExecutor) { objects ->
                    if (motion && objects.isNotEmpty() && now - lastAlert > 15_000) {
                        lastAlert = now
                        val jpeg = try { ImageUtil.yuvToJpeg(image) } catch (_: Exception) { null }
                        val eventId = raiseAlert(cam.name, summarize(objects), jpeg)
                        startClip(eventId, now)
                    }
                }
                .addOnCompleteListener(mlExecutor) {
                    image.close()
                    busy = false
                }
        }

        /** Once a second: keep a rolling pre-alert buffer, or add to the clip being recorded. */
        private fun captureClipFrame(image: Image, now: Long) {
            if (now - lastClipTick < 1000) return
            lastClipTick = now
            val jpeg = try { ImageUtil.yuvToJpeg(image, 60) } catch (_: Exception) { return }
            var finished: Pair<Long, List<ByteArray>>? = null
            synchronized(this) {
                val clip = clipFrames
                if (clip != null) {
                    clip.add(jpeg)
                    if (now >= clipEnd) {
                        finished = clipEventId to clip.toList()
                        clipFrames = null
                    }
                } else {
                    preRoll.addLast(jpeg)
                    if (preRoll.size > 3) preRoll.removeFirst()
                }
            }
            finished?.let { (id, frames) -> AlertLog.attachClip(this@IpMonitorService, id, frames) }
        }

        @Synchronized
        private fun startClip(eventId: Long, now: Long) {
            if (clipFrames != null) return
            clipFrames = preRoll.toMutableList()
            preRoll.clear()
            clipEventId = eventId
            clipEnd = now + 8_000
        }

        private fun summarize(objects: List<DetectedObject>): String =
            objects.groupingBy { it.labels.firstOrNull()?.text ?: "object" }.eachCount()
                .entries.joinToString(", ") { "${it.value} ${it.key}" }

        /** Compares a 32x18 grid of brightness samples between consecutive frames. */
        private fun detectMotion(image: Image): Boolean {
            val plane = image.planes[0]
            val buf = plane.buffer
            val sample = ByteArray(32 * 18)
            for (gy in 0 until 18) {
                for (gx in 0 until 32) {
                    val pos = (gy * image.height / 18) * plane.rowStride + (gx * image.width / 32)
                    sample[gy * 32 + gx] = if (pos < buf.limit()) buf.get(pos) else 0
                }
            }
            val prev = previous
            previous = sample
            if (prev == null) return false
            val changed = sample.indices.count {
                abs((sample[it].toInt() and 0xFF) - (prev[it].toInt() and 0xFF)) > 25
            }
            return changed.toDouble() / sample.size > cam.motionThreshold
        }
    }

    companion object {
        @Volatile var running = false

        fun start(context: Context) =
            ContextCompat.startForegroundService(context, Intent(context, IpMonitorService::class.java))

        fun stop(context: Context) =
            context.stopService(Intent(context, IpMonitorService::class.java))
    }
}
