package com.safeeye

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Simple screen where the user enters up to 5 trusted contacts for SOS messages. */
class SettingsActivity : AppCompatActivity() {

    private val fields = mutableListOf<EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Trusted contacts"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "SOS messages with your location are sent to these numbers. Use the international format, e.g. +254700000000."
            setPadding(0, pad / 2, 0, pad)
        })

        val saved = ContactsStore.load(this)
        for (i in 0 until 5) {
            val field = EditText(this).apply {
                hint = "Contact ${i + 1}"
                inputType = InputType.TYPE_CLASS_PHONE
                setText(saved.getOrNull(i) ?: "")
            }
            fields += field
            root.addView(field)
        }

        root.addView(Button(this).apply {
            text = "Save"
            setOnClickListener { save() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad; gravity = Gravity.CENTER })

        setContentView(root)
    }

    private fun save() {
        val numbers = fields.map { it.text.toString().trim() }.filter { it.isNotEmpty() }
        val bad = numbers.firstOrNull { !ContactsStore.isValid(it) }
        if (bad != null) {
            Toast.makeText(this, "Invalid number: $bad (use +country code)", Toast.LENGTH_LONG).show()
            return
        }
        ContactsStore.save(this, numbers)
        Toast.makeText(this, "Saved ${numbers.size} contact(s)", Toast.LENGTH_SHORT).show()
        finish()
    }
}
