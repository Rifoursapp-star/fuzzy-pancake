package com.safeeye

import android.graphics.Rect
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

data class Detection(val id: Int?, val label: String, val box: Rect)

/**
 * Real-time on-device AI: detects and tracks objects (any prominent object, with a
 * broad category label) and flags motion by comparing consecutive frames. Works offline.
 * It does NOT say "person" specifically; for that, swap in a TensorFlow Lite / MediaPipe
 * EfficientDet or YOLO model (the desktop version already uses YOLO).
 *
 * Range note: how far this can "see" depends on the lens and sensor resolution.
 * Pair it with a zoom lens, a security camera stream, or a thermal/radar sensor
 * for long-distance coverage.
 */
class DetectionAnalyzer(
    /** Called (at most every 15 s) when something is moving in view, with a JPEG snapshot. */
    private val onSnapshot: ((jpeg: ByteArray, description: String) -> Unit)? = null,
    private val onResult: (detections: List<Detection>, motion: Boolean) -> Unit
) : ImageAnalysis.Analyzer {

    private var lastSnapshot = 0L

    private val detector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE) // tracking IDs across frames
            .enableClassification()
            .enableMultipleObjects()
            .build()
    )

    private var previous: ByteArray? = null

    override fun analyze(image: ImageProxy) {
        val motion = detectMotion(image)
        val media = image.image
        if (media == null) {
            image.close()
            return
        }
        val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
        detector.process(input)
            .addOnSuccessListener { objects ->
                val found = objects.map {
                    Detection(
                        id = it.trackingId,
                        label = it.labels.firstOrNull()?.text ?: "object",
                        box = it.boundingBox
                    )
                }
                onResult(found, motion)

                val now = System.currentTimeMillis()
                if (onSnapshot != null && motion && found.isNotEmpty() && now - lastSnapshot > 15_000) {
                    lastSnapshot = now
                    try {
                        val jpeg = ImageUtil.bitmapToJpeg(image.toBitmap(), image.imageInfo.rotationDegrees)
                        val summary = found.groupingBy { it.label }.eachCount()
                            .entries.joinToString(", ") { "${it.value} ${it.key}" }
                        onSnapshot.invoke(jpeg, summary)
                    } catch (_: Exception) { /* snapshot is optional */ }
                }
            }
            .addOnCompleteListener { image.close() }
    }

    /** Cheap motion check: compares a sparse sample of luminance pixels between frames. */
    private fun detectMotion(image: ImageProxy): Boolean {
        val plane = image.planes[0].buffer
        val step = 64
        val size = plane.remaining() / step
        val sample = ByteArray(size)
        for (i in 0 until size) sample[i] = plane.get(i * step)
        plane.rewind()

        val prev = previous
        previous = sample
        if (prev == null || prev.size != sample.size) return false

        var changed = 0
        for (i in sample.indices) {
            if (kotlin.math.abs((sample[i].toInt() and 0xFF) - (prev[i].toInt() and 0xFF)) > 25) changed++
        }
        return changed.toDouble() / size > 0.03 // >3% of sampled pixels changed
    }
}
