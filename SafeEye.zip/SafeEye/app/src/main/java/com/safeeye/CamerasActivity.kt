package com.safeeye

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Manage IP / RTSP cameras and start or stop watching all of them in the background. */
class CamerasActivity : AppCompatActivity() {

    private var cameras = mutableListOf<IpCamera>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var toggle: Button
    private val dp by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "IP / long-range cameras"
            textSize = 24f
        })

        val nameInput = EditText(this).apply { hint = "Name (e.g. Gate)" }
        val urlInput = EditText(this).apply {
            hint = "rtsp://user:pass@192.168.1.10:554/stream1"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        root.addView(nameInput)
        root.addView(urlInput)
        root.addView(Button(this).apply {
            text = "Add camera"
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                val url = urlInput.text.toString().trim()
                when {
                    name.isEmpty() -> toast("Give the camera a name")
                    !url.startsWith("rtsp://") -> toast("Address must start with rtsp://")
                    else -> {
                        cameras.add(IpCamera(name, url))
                        CameraStore.save(this@CamerasActivity, cameras)
                        nameInput.text.clear(); urlInput.text.clear()
                        refresh()
                    }
                }
            }
        })

        root.addView(Button(this).apply {
            text = "Find Refours Cams on this Wi-Fi"
            setOnClickListener { findRefoursCams() }
        })

        root.addView(TextView(this).apply {
            text = "Tap a camera to view it, change its settings, or remove it."
            setPadding(0, pad / 2, 0, pad / 2)
        })

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        root.addView(ListView(this).apply {
            adapter = this@CamerasActivity.adapter
            setOnItemClickListener { _, _, i, _ -> showMenu(i) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        toggle = Button(this).apply {
            setOnClickListener {
                if (IpMonitorService.running) {
                    IpMonitorService.stop(this@CamerasActivity)
                } else if (cameras.isEmpty()) {
                    toast("Add a camera first")
                } else {
                    IpMonitorService.start(this@CamerasActivity)
                }
                postDelayed({ refresh() }, 500)
            }
        }
        root.addView(toggle)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        cameras = CameraStore.load(this)
        adapter.clear()
        adapter.addAll(cameras.map { describe(it) })
        toggle.text = if (IpMonitorService.running) "Stop background monitoring"
        else "Start background monitoring (${cameras.size} camera(s))"
    }

    private fun describe(c: IpCamera): String {
        val sens = listOf("low", "medium", "high")[c.sensitivity]
        val hours = if (c.startHour == c.endHour) "always" else "%02d:00-%02d:00".format(c.startHour, c.endHour)
        val host = Uri.parse(c.url).host ?: "camera"
        return "${c.name}  ($host)\nSensitivity $sens | ${if (c.clips) "clips" else "snapshots"} | $hours"
    }

    private fun showMenu(i: Int) {
        val cam = cameras[i]
        AlertDialog.Builder(this)
            .setTitle(cam.name)
            .setItems(arrayOf("View live", "Settings", "Remove")) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, StreamActivity::class.java).putExtra("url", cam.url))
                    1 -> showSettings(i)
                    2 -> {
                        cameras.removeAt(i)
                        saveAndApply()
                    }
                }
            }
            .show()
    }

    private fun showSettings(i: Int) {
        val cam = cameras[i]
        val p = (20 * dp).toInt()
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, 0)
        }
        form.addView(TextView(this).apply { text = "Sensitivity (how easily movement triggers an alert)" })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@CamerasActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Low (fewer alerts)", "Medium", "High (very sensitive)")
            )
            setSelection(cam.sensitivity)
        }
        form.addView(spinner)
        val clips = CheckBox(this).apply {
            text = "Save a short clip (about 8 seconds) with each alert"
            isChecked = cam.clips
        }
        form.addView(clips)
        form.addView(TextView(this).apply {
            text = "Watch only between these hours (0-23). Same start and end = always. Example: 20 to 6 = overnight."
            setPadding(0, p / 2, 0, 0)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = EditText(this).apply {
            hint = "Start"; inputType = InputType.TYPE_CLASS_NUMBER; setText(cam.startHour.toString())
        }
        val end = EditText(this).apply {
            hint = "End"; inputType = InputType.TYPE_CLASS_NUMBER; setText(cam.endHour.toString())
        }
        row.addView(start, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(end, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        form.addView(row)

        AlertDialog.Builder(this)
            .setTitle("${cam.name} settings")
            .setView(form)
            .setPositiveButton("Save") { _, _ ->
                cameras[i] = cam.copy(
                    sensitivity = spinner.selectedItemPosition,
                    clips = clips.isChecked,
                    startHour = (start.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23),
                    endHour = (end.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
                )
                saveAndApply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Saves, and if monitoring is running, restarts it so changes take effect right away. */
    private fun saveAndApply() {
        CameraStore.save(this, cameras)
        if (IpMonitorService.running) {
            if (cameras.isEmpty()) IpMonitorService.stop(this) else IpMonitorService.start(this)
        }
        refresh()
    }

    /** Looks for Refours Cams for 5 seconds, then lets the user pick one and enter its pairing code. */
    private fun findRefoursCams() {
        val found = java.util.Collections.synchronizedList(mutableListOf<RefoursCam>())
        val discovery = RefoursDiscovery(this) { found += it }
        discovery.start()
        toast("Searching for Refours Cams...")
        window.decorView.postDelayed({
            discovery.stop()
            if (found.isEmpty()) {
                AlertDialog.Builder(this)
                    .setMessage("No Refours Cam found. Check it is powered and on the same Wi-Fi as this phone.")
                    .setPositiveButton("OK", null).show()
                return@postDelayed
            }
            val list = found.toList()
            AlertDialog.Builder(this)
                .setTitle("Refours Cams found")
                .setItems(list.map { "${it.name}  (${it.host})" }.toTypedArray()) { _, i -> askCode(list[i]) }
                .show()
        }, 5000)
    }

    private fun askCode(cam: RefoursCam) {
        val input = EditText(this).apply {
            hint = "Pairing code (10 characters)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this)
            .setTitle("Pair ${cam.name}")
            .setMessage("Enter the pairing code shown by the camera.")
            .setView(input)
            .setPositiveButton("Pair") { _, _ ->
                val code = input.text.toString().trim().uppercase()
                Thread {
                    val ok = RefoursDiscovery.codeIsValid(cam, code)
                    runOnUiThread {
                        if (!ok) { toast("Wrong code, or the camera cannot be reached"); return@runOnUiThread }
                        var name = cam.name
                        if (cameras.any { it.name == name }) name = "$name ${cam.id.take(4)}"
                        cameras.add(IpCamera(name, cam.rtspUrl(code)))
                        CameraStore.save(this, cameras)
                        refresh()
                        toast("Paired with $name")
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
