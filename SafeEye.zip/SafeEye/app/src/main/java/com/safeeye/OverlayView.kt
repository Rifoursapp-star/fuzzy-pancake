package com.safeeye

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Draws boxes and labels around detected objects on top of the camera preview. */
class OverlayView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private var detections: List<Detection> = emptyList()
    private var srcW = 1
    private var srcH = 1

    private val boxPaint = Paint().apply {
        color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val textPaint = Paint().apply {
        color = Color.WHITE; textSize = 38f; setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun update(list: List<Detection>, sourceWidth: Int, sourceHeight: Int) {
        detections = list; srcW = sourceWidth; srcH = sourceHeight
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val sx = width / srcW.toFloat()
        val sy = height / srcH.toFloat()
        for (d in detections) {
            val b = d.box
            canvas.drawRect(b.left * sx, b.top * sy, b.right * sx, b.bottom * sy, boxPaint)
            canvas.drawText("${d.label} #${d.id ?: "-"}", b.left * sx, b.top * sy - 8f, textPaint)
        }
    }
}
