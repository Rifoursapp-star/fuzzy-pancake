package com.safeeye.wear

import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.app.Activity
import com.google.android.gms.wearable.Wearable

/**
 * Watch SOS: press and HOLD the red button for about a second.
 * The watch sends a message to the paired phone, and the phone's SafeEye
 * sends your location to the trusted contacts.
 */
class WearMainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
        }
        val button = Button(this).apply {
            text = "HOLD\nfor SOS"
            textSize = 18f
            setBackgroundColor(0xFFD32F2F.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnLongClickListener { sendSos(); true }
        }
        status = TextView(this).apply {
            text = "SafeEye by Refours Systems"
            textSize = 11f
            gravity = Gravity.CENTER
        }
        root.addView(button, LinearLayout.LayoutParams(280, 280))
        root.addView(status)
        setContentView(root)
    }

    private fun sendSos() {
        buzz()
        status.text = "Sending SOS..."
        Wearable.getNodeClient(this).connectedNodes
            .addOnSuccessListener { nodes ->
                if (nodes.isEmpty()) {
                    status.text = "Phone not connected"
                    return@addOnSuccessListener
                }
                nodes.forEach { node ->
                    Wearable.getMessageClient(this)
                        .sendMessage(node.id, SOS_PATH, "SOS".toByteArray())
                        .addOnSuccessListener { status.text = "SOS sent to phone" }
                        .addOnFailureListener { status.text = "Could not reach phone" }
                }
            }
            .addOnFailureListener { status.text = "Could not reach phone" }
    }

    private fun buzz() {
        getSystemService(Vibrator::class.java)
            ?.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    companion object {
        const val SOS_PATH = "/safeeye/sos"
    }
}
